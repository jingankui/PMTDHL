#define NOMINMAX
#include <algorithm>
#include <iostream>
#include <vector>
#include <queue>
#include <set>
#include <unordered_map>
using namespace std;

template<typename T>
inline const T& mymin(const T& a, const T& b) {
	return (a < b) ? a : b;
}
template<typename T>
inline const T& mymax(const T& a, const T& b) {
	return (a > b) ? a : b;
}
template<typename T, typename U>
inline auto mymin(const T& a, const U& b) -> decltype(a < b ? a : b) {
	return (a < b) ? a : b;
}
template<typename T, typename U>
inline auto mymax(const T& a, const U& b) -> decltype(a > b ? a : b) {
	return (a > b) ? a : b;
}

typedef long long ll;
typedef pair<ll, ll> Node;
typedef vector<vector<Node>> Graph;
typedef priority_queue<Node, vector<Node>, greater<Node>> DijkstraQueue;

const ll INF = 1e15 + 10;
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

class CH {
private:
	int n, m, order;
	vector<Graph> G, G_CH;  // 仅存图结构（只读，线程安全）
	DijkstraQueue imp_pq;
	vector<bool> contracted;
	vector<int> imp;
	vector<int> level;
	vector<int> contr_neighbours;

	// ====================== 核心改造：局部变量，无共享状态 ======================
	ll GetDistance(int s, int t) {
		// dist/pq 改为局部变量，每个查询独立，多线程100%安全
		vector<vector<ll>> dist(2, vector<ll>(n + 1, INF));
		vector<DijkstraQueue> pq(2);

		dist[0][s] = dist[1][t] = 0;
		ll SP = INF;
		pq[0].push(mp(0, s));
		pq[1].push(mp(0, t));
		Node front;
		int curr_node;
		ll curr_dist;

		while (!pq[0].empty() || !pq[1].empty()) {
			if (!pq[0].empty()) {
				front = pq[0].top(); pq[0].pop();
				curr_node = front.sc; curr_dist = front.fs;
				if (SP >= curr_dist) RelaxNodeEdges(curr_node, 0, dist, pq);
				SP = mymin(SP, dist[0][curr_node] + dist[1][curr_node]);
			}
			if (!pq[1].empty()) {
				front = pq[1].top(); pq[1].pop();
				curr_node = front.sc; curr_dist = front.fs;
				if (SP >= curr_dist) RelaxNodeEdges(curr_node, 1, dist, pq);
				SP = mymin(SP, dist[0][curr_node] + dist[1][curr_node]);
			}
		}
		return (SP == INF) ? -1 : SP;
	}

	void RelaxNodeEdges(int u, int g, vector<vector<ll>>& dist, vector<DijkstraQueue>& pq) {
		int v; ll w;
		for (auto& p : G_CH[g][u]) {
			v = p.fs, w = p.sc;
			if (dist[g][v] > dist[g][u] + w) {
				dist[g][v] = dist[g][u] + w;
				pq[g].push(mp(dist[g][v], v));
			}
		}
	}
	// ==========================================================================

	void read() {
		graph >> n >> m;
		G.assign(2, Graph(n + 1, vector<Node>()));
		int u, v, w;
		for (int i = 0; i < m; ++i) {
			graph >> u >> v >> w;
			if (u == v) continue;
			Connect(G[0][u], v, w);
			Connect(G[1][v], u, w);
		}
	}
	void preprocess() { SetOrder(); BuildG_CH(); }
	void Connect(vector<Node>& E, int v, ll w) {
		for (auto& p : E) if (p.fs == v) { p.sc = mymin(p.sc, w); return; }
		E.pb(mp(v, w));
	}
	void SetOrder() {
		contracted.assign(n + 1, 0); imp.assign(n + 1, 0);
		level.assign(n + 1, 0); contr_neighbours.assign(n + 1, 0);
		for (int i = 1; i <= n; ++i) imp_pq.push(mp(-n, i));
		int curr_node, new_imp; order = 1;
		while (!imp_pq.empty()) {
			curr_node = imp_pq.top().sc; imp_pq.pop();
			new_imp = GetImportance(curr_node);
			if (imp_pq.empty() || new_imp - imp_pq.top().fs <= 10) {
				imp[curr_node] = order++; contracted[curr_node] = 1;
				ContractNode(curr_node);
			}
			else imp_pq.push(mp(new_imp, curr_node));
		}
	}
	int GetImportance(int x) {
		int u, v, shortcuts = 0, in_out = 0;
		for (int i = 0; i < 2; ++i) for (auto& p : G[i][x]) if (!contracted[p.fs]) ++in_out;
		for (auto& p1 : G[1][x]) for (auto& p2 : G[0][x]) {
			u = p1.fs; v = p2.fs; if (!contracted[u] && !contracted[v]) ++shortcuts;
		}
		int edge_diff = shortcuts - in_out;
		return edge_diff + 2 * contr_neighbours[x] + level[x];
	}
	void ContractNode(int x) {
		int u; ll w, mx = GetMaxEdge(x);
		set<pair<int, ll>> out_edges;
		for (auto& p : G[0][x]) if (!contracted[p.fs]) out_edges.insert(mp(p.fs, p.sc));
		for (auto& p : G[1][x]) {
			u = p.fs; if (contracted[u]) continue;
			w = p.sc; Check_Witness(u, x, w, mx, out_edges, 0);
		}
		for (int i = 0; i < 2; ++i) for (auto& p : G[i][x]) {
			++contr_neighbours[p.fs];
			level[p.fs] = std::max(level[p.fs], level[x] + 1);
		}
	}
	ll GetMaxEdge(int x) {
		ll ret = 0;
		for (auto& p1 : G[1][x]) for (auto& p2 : G[0][x])
			if (p1.fs != p2.fs && !contracted[p1.fs] && !contracted[p2.fs])
				ret = mymax(ret, p1.sc + p2.sc);
		return ret;
	}
	int Check_Witness(int u, int x, ll w, ll mx, set<pair<int, ll>>& out_edges, bool type) {
		int a, b; ll curr_dist, new_dist;
		DijkstraQueue D_pq; unordered_map<int, ll> D_dist;
		D_pq.push(mp(0, u)); D_dist[u] = 0;
		int iter = 250 * (n - order) / n;
		while (!D_pq.empty() && iter--) {
			curr_dist = D_pq.top().fs; a = D_pq.top().sc; D_pq.pop();
			if (curr_dist > D_dist[a]) continue;
			for (auto& p : G[0][a]) {
				new_dist = p.sc + curr_dist; b = p.fs;
				if (b != x && !contracted[b])
					if (!D_dist.count(b) || D_dist[b] > new_dist)
						if (D_dist[b] < mx) D_dist[b] = new_dist, D_pq.push(mp(new_dist, b));
			}
		}
		int v, ret = 0; ll new_w;
		for (auto& p : out_edges) {
			v = p.fs, new_w = w + p.sc;
			if (!D_dist.count(v) || D_dist[v] > new_w) {
				++ret; if (!type && u != v) { Connect(G[0][u], v, new_w); Connect(G[1][v], u, new_w); }
			}
		}
		return ret;
	}
	void BuildG_CH() {
		G_CH.assign(2, Graph(n + 1, vector<Node>()));
		int v; ll w;
		for (int u = 1; u <= n; ++u) for (auto& p : G[0][u]) {
			v = p.fs; w = p.sc;
			if (imp[v] > imp[u]) G_CH[0][u].pb(mp(v, w));
			else G_CH[1][v].pb(mp(u, w));
		}
	}

public:
	CH() { cout << "Preprocessing...\n"; read(); preprocess(); cout << "Preprocessing done!\n"; }
	// 线程安全查询！全局单例直接调用，无需复制
	ll Query(int _s, int _t) { return GetDistance(_s, _t); }
};