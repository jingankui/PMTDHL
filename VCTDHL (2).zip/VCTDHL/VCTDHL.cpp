#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <memory>
#include <stack>
#include <limits>
#include <filesystem>
#include <string>
#include <mutex>
#include <thread>
#include <future>
#include <random>
#include <atomic>
#include <omp.h>
#include <ctime>


using namespace std;

ifstream graph("BAY.txt");
//ifstream graph("Road-net-roma.txt");
#include "ch.h"

using namespace chrono;
namespace fs = std::filesystem;
atomic<int> g_completed_partitions = 0;
int g_total_valid_partitions = 0;
mutex g_print_mutex;

int T = clock();
CH G;
const double EPS = 1e-10;
typedef long long ll;

// 最终修复版CHQuery（无向/有向通用）
vector<ll> CHQuery(int size, int s, vector<int> hubs, bool isdirected) {
    vector<ll> dists(hubs.size(), INF);

    // 自己到自己距离=0
    for (int i = 0; i < hubs.size(); ++i) {
        if (hubs[i] == s) {
            dists[i] = 0;
        }
    }

    ios::sync_with_stdio(false); cin.tie(nullptr);
    if (!isdirected) {
        // 无向图：s -> t
        for (int i = 0; i < hubs.size(); ++i) {
            int t = hubs[i];
            if (t == s) continue;
            ll res = G.Query(s, t);
            dists[i] = (res == -1) ? INF : res; // 修复：-1=不可达=INF
        }
    }
    else {
        // 有向图：t -> s
        for (int i = 0; i < hubs.size(); ++i) {
            int t = hubs[i];
            if (t == s) continue;
            ll res = G.Query(t, s);
            dists[i] = (res == -1) ? INF : res; // 修复：-1=不可达=INF
        }
    }
    return dists;
}

struct Edge {
    int u, v;
    double weight;
    Edge(int from, int to, double w) : u(from), v(to), weight(w) {}
};

struct TreeNode {
    int id;
    int repre;
    set<int> vertices;
    vector<int> ancestors;
    vector<int> acce;
    vector<double> accedist;
    vector<ll> dist_out;
    vector<ll> dist_in;
    vector<int> pos;
    TreeNode* parent;
    vector<TreeNode*> children;
    int level;
    int eliminationOrder;

    // 有向图新增：phi_in = xj -> v（反向包内距离）
    unordered_map<int, ll> phi;    // v -> xj (通用)
    unordered_map<int, ll> phi_in; // xj -> v (仅有向图)
    vector<int> hubs;

    TreeNode(int nodeId) : id(nodeId), repre(nodeId), parent(nullptr), level(0), eliminationOrder(-1) {
        vertices.insert(nodeId);
    }
};

class OriginalGraph {
public:
    unordered_map<int, vector<pair<int, double>>> adjList;
    set<int> vertices;
    vector<Edge> edges;

    void addEdge(int from, int to, double weight) {
        adjList[from].emplace_back(to, weight);
        edges.emplace_back(from, to, weight);
        vertices.insert(from);
        vertices.insert(to);
    }
    int getVertexCount() const { return vertices.size(); }
    int getEdgeCount() const { return edges.size(); }
};

class Graphs {
public:
    unordered_map<int, vector<pair<int, double>>> adjList;
    set<int> vertices;
    vector<Edge> edges;
    string graphName;
    bool isDirected;

    Graphs() : isDirected(false) {}
    bool empty() const { return vertices.empty(); }

    void buildFromOriginal(const OriginalGraph& og, const string& name, bool directed = false) {
        graphName = name;
        isDirected = directed;
        vertices = og.vertices;
        adjList = og.adjList;
        edges = og.edges;
    }

    string getName() const { return graphName; }
    int getVertexCount() const { return vertices.size(); }
    int getEdgeCount() const { return edges.size(); }

    vector<int> getAllNeighbors(int u) const {
        vector<int> nbrs;
        auto it = adjList.find(u);
        if (it != adjList.end()) {
            for (const auto& [v, _] : it->second) nbrs.push_back(v);
        }
        sort(nbrs.begin(), nbrs.end());
        nbrs.erase(unique(nbrs.begin(), nbrs.end()), nbrs.end());
        return nbrs;
    }

    vector<int> getOutNeighbors(int u) const {
        vector<int> nbrs;
        auto it = adjList.find(u);
        if (it != adjList.end()) {
            for (const auto& [v, _] : it->second) nbrs.push_back(v);
        }
        return nbrs;
    }

    double getEdgeWeight(int u, int v) const {
        auto it = adjList.find(u);
        if (it != adjList.end()) {
            for (const auto& [nbr, w] : it->second) if (nbr == v) return w;
        }
        return INF;
    }
};

struct PartitionResult {
    int partitionId;
    int treeWidth;
    size_t indexSize;
    string statistics;
    string indexData;
    bool success;
    double treeDecompTimeMs;
    double hubLabelTimeMs;
};

class TDHL {
private:
    Graphs graph;
    unordered_map<int, TreeNode*> treeNodes;
    TreeNode* root;
    int treeWidth;
    int maxTreeNodeSize;
    vector<int> eliminationOrder;
    mt19937 rng;
    unordered_map<int, unordered_set<int>> fastEdgeCheck;

    double treeDecompTimeMs = 0;
    double hubLabelTimeMs = 0;

    void initFastEdgeCheck() {
        fastEdgeCheck.clear();
        for (const auto& [v, neighbors] : graph.adjList) {
            for (const auto& [n, w] : neighbors) fastEdgeCheck[v].insert(n);
        }
    }

    bool edgeExists(int u, int v) {
        auto it = fastEdgeCheck.find(u);
        if (it == fastEdgeCheck.end()) return false;
        return it->second.count(v) > 0;
    }

    double directedDijkstra(int source, int target) {
        if (source == target) return 0.0;
        unordered_map<int, double> dist;
        priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
        dist[source] = 0.0; pq.emplace(0.0, source);
        while (!pq.empty()) {
            auto [d, u] = pq.top(); pq.pop();
            if (u == target) return d;
            if (d > dist[u]) continue;
            auto it = graph.adjList.find(u);
            if (it != graph.adjList.end()) {
                for (auto [v, w] : it->second) {
                    double nd = d + w;
                    if (!dist.count(v) || nd < dist[v]) {
                        dist[v] = nd; pq.emplace(nd, v);
                    }
                }
            }
        }
        return INF;
    }

    double undirectedDijkstra(int source, int target) {
        return directedDijkstra(source, target);
    }

    void buildTreeDecomposition() {
        cout << "  -> Building tree decomposition...\n";
        //auto start = high_resolution_clock::now();

        if (graph.empty()) { treeWidth = 0; maxTreeNodeSize = 0; return; }
        for (int v : graph.vertices) if (!treeNodes.count(v)) treeNodes[v] = new TreeNode(v);

        unordered_map<int, set<int>> undirNei;
        unordered_map<int, vector<pair<int, double>>> undirAdj;
        for (auto& [u, vs] : graph.adjList) for (auto& [v, w] : vs) {
            undirNei[u].insert(v); undirNei[v].insert(u);
            undirAdj[u].emplace_back(v, w); undirAdj[v].emplace_back(u, w);
        }

        auto currNei = undirNei;
        auto currAdj = undirAdj;
        unordered_set<int> proc;
        eliminationOrder.clear();
        int step = 0, total = graph.vertices.size();
        long long fill = 0, upd = 0;
        unordered_map<int, vector<int>> acceMap;
        unordered_map<int, vector<double>> accdMap;

        while (proc.size() < total) {
            vector<int> cand;
            for (int v : graph.vertices) if (!proc.count(v)) cand.push_back(v);
            if (cand.empty()) break;

            int minDeg = INT_MAX;
            for (int v : cand) minDeg = min(minDeg, (int)currNei[v].size());
            vector<int> mdc;
            for (int v : cand) if (currNei[v].size() == minDeg) mdc.push_back(v);
            int sel = mdc[0];

            eliminationOrder.push_back(sel);
            vector<int> nei(currNei[sel].begin(), currNei[sel].end());
            vector<double> w;
            for (int n : nei) {
                double d = INF;
                for (auto& p : currAdj[sel]) if (p.first == n) { d = p.second; break; }
                w.push_back(d);
            }
            acceMap[sel] = nei; accdMap[sel] = w;

            auto node = treeNodes[sel];
            node->vertices.clear(); node->vertices.insert(sel);
            for (int n : nei) node->vertices.insert(n);
            node->acce = nei; node->accedist = w;

            for (int i = 0; i < nei.size(); i++) for (int j = i + 1; j < nei.size(); j++) {
                int a = nei[i], b = nei[j];
                double wa = INF, wb = INF;
                for (auto& p : currAdj[a])if (p.first == sel)wa = p.second;
                for (auto& p : currAdj[sel])if (p.first == b)wb = p.second;
                double sum = wa + wb;

                bool ex = false; double old = INF; int pos = -1;
                for (int k = 0; k < currAdj[a].size(); k++) {
                    if (currAdj[a][k].first == b) { old = currAdj[a][k].second; pos = k; ex = true; break; }
                }
                if (!ex) {
                    currAdj[a].emplace_back(b, sum); currAdj[b].emplace_back(a, sum);
                    currNei[a].insert(b); currNei[b].insert(a); fill++;
                }
                else if (sum < old - EPS) {
                    currAdj[a][pos].second = sum;
                    for (int k = 0; k < currAdj[b].size(); k++)if (currAdj[b][k].first == a) { currAdj[b][k].second = sum; break; }
                    upd++;
                }
            }
            proc.insert(sel);
            for (int n : nei)currNei[n].erase(sel);
            currNei.erase(sel); currAdj.erase(sel);
            for (auto& p : currAdj) {
                auto& v = p.second;
                v.erase(remove_if(v.begin(), v.end(), [sel](auto& x) {return x.first == sel; }), v.end());
            }
            step++;
        }

        for (auto& p : acceMap) { int v = p.first; treeNodes[v]->acce = p.second; treeNodes[v]->accedist = accdMap[v]; }
        int rootv = eliminationOrder.back();
        root = treeNodes[rootv]; root->parent = nullptr; root->level = 0;
        for (int i = 0; i < eliminationOrder.size() - 1; i++) {
            int v = eliminationOrder[i]; auto n = treeNodes[v];
            int par = -1;
            for (int j = i + 1; j < eliminationOrder.size(); j++) {
                int c = eliminationOrder[j];
                if (find(acceMap[v].begin(), acceMap[v].end(), c) != acceMap[v].end()) {
                    par = c;
                    break;
                }
            }
            if (par == -1)par = rootv;
            n->parent = treeNodes[par]; treeNodes[par]->children.push_back(n); n->level = treeNodes[par]->level + 1;
        }

        for (auto& kv : treeNodes) {
            auto n = kv.second; n->ancestors.clear();
            vector<int> path; auto p = n->parent;
            while (p) { path.push_back(p->id); p = p->parent; }
            reverse(path.begin(), path.end()); path.push_back(n->id); n->ancestors = path;
        }

        maxTreeNodeSize = 0;
        for (auto& kv : treeNodes)maxTreeNodeSize = max(maxTreeNodeSize, (int)kv.second->vertices.size());
        treeWidth = maxTreeNodeSize - 1;

        auto start = high_resolution_clock::now();
        // ====================== 核心修改：分图类型计算包内距离 ======================
        cout << "  -> Precompute package shortest paths (CH)...\n";
        int total_nodes = treeNodes.size();
        int curr_node = 0;
        bool is_directed = graph.isDirected;

        for (auto& kv : treeNodes) {
            TreeNode* n = kv.second;
            int v = n->repre;
            n->phi.clear();
            if (is_directed) n->phi_in.clear();

            vector<int> package_nodes = n->acce;

            // 1. 通用：v -> xj
            vector<ll> dist_forward = CHQuery(package_nodes.size(), v, package_nodes, false);
            for (int i = 0; i < package_nodes.size(); ++i) {
                int xj = package_nodes[i];
                n->phi[xj] = dist_forward[i];
            }

            // 2. 仅有向图：xj -> v
            if (is_directed) {
                //cout << "  directed graph haha \n";
                vector<ll> dist_backward = CHQuery(package_nodes.size(), v, package_nodes, is_directed);
                for (int i = 0; i < package_nodes.size(); ++i) {
                    int xj = package_nodes[i];
                    n->phi_in[xj] = dist_backward[i];
                }
            }

            n->phi[v] = 0;
            if (is_directed) n->phi_in[v] = 0;
            curr_node++;
            if (total_nodes > 0 && curr_node % (total_nodes / 10 + 1) == 0) {
                lock_guard<mutex> lock(g_print_mutex);
                cout << "    -> Partition package progress: " << (curr_node * 100 / total_nodes) << "%\n";
            }
        }
        // ============================================================================

        auto end = high_resolution_clock::now();
        treeDecompTimeMs = duration_cast<microseconds>(end - start).count() / 1000.0;
        cout << "  -> Tree decomposition done! Time: " << treeDecompTimeMs << " ms\n";
    }
    
    void buildHubLabelingDirected() {
        cout << "  -> Building directed hub labeling...\n";
        auto start = high_resolution_clock::now();

        if (graph.empty()) return;

        // 从上到下 BFS（祖先先算，正确）
        queue<TreeNode*> q;
        q.push(root);

        while (!q.empty()) {
            TreeNode* n = q.front();
            q.pop();

            n->hubs = n->ancestors;
            n->pos.clear();
            auto add_pos = [&](int u) {
                auto it = find(n->hubs.begin(), n->hubs.end(), u);
                if (it != n->hubs.end()) {
                    n->pos.push_back(it - n->hubs.begin());
                }
                };
            for (int a : n->acce) add_pos(a);
            add_pos(n->repre);

            int hub_num = n->hubs.size();
            n->dist_out.assign(hub_num, INF);
            n->dist_in.assign(hub_num, INF);

            if (n == root) {
                for (int i = 0; i < hub_num; ++i) {
                    if (n->hubs[i] == n->repre) {
                        n->dist_out[i] = 0;
                        n->dist_in[i] = 0;
                    }
                }
            }
            else {
                // -------------------- dist_out --------------------
                for (int h_idx = 0; h_idx < hub_num; ++h_idx) {
                    int h = n->hubs[h_idx];
                    if (h == n->repre) {
                        n->dist_out[h_idx] = 0;
                        continue;
                    }
                    TreeNode* h_node = treeNodes[h];
                    ll min_d = INF;
                    auto it_phi = n->phi.find(h);
                    if (it_phi != n->phi.end()) {
                        min_d = it_phi->second;
                    }

                    // ====================== 新增 ======================
                    // 上层已计算枢纽中转（核心最优路径）
                    for (int k = 0; k < h_idx; k++) {
                        int hk = n->hubs[k];
                        TreeNode* hk_node = treeNodes[hk];
                        auto it = find(h_node->hubs.begin(), h_node->hubs.end(), hk);
                        if (it != h_node->hubs.end()) {
                            int idx = it - h_node->hubs.begin();
                            ll d1 = n->dist_out[k];
                            ll d2 = h_node->dist_in[idx];
                            if (d1 < INF && d2 < INF) {
                                min_d = min(min_d, d1 + d2);
                            }
                        }
                    }
                    for (int xj : n->acce) {
                        TreeNode* xj_node = treeNodes[xj];
                      
                        if (xj_node->level < h_node->level) continue;

                        ll v2xj = INF;
                        auto it_vxj = n->phi.find(xj);
                        if (it_vxj != n->phi.end()) {
                            v2xj = it_vxj->second;
                        }
                        if (v2xj == INF) continue;

                        ll xj2h = INF;
                        if (h_node->level <= xj_node->level) {
                            auto it = find(xj_node->hubs.begin(), xj_node->hubs.end(), h);
                            if (it != xj_node->hubs.end()) {
                                int idx = it - xj_node->hubs.begin();
                                xj2h = xj_node->dist_out[idx];
                            }
                        }
                        if (xj2h < INF) {
                            min_d = min(min_d, v2xj + xj2h);
                        }
                    }
                    n->dist_out[h_idx] = min_d;
                }

                // -------------------- dist_in --------------------
                for (int h_idx = 0; h_idx < hub_num; ++h_idx) {
                    int h = n->hubs[h_idx];
                    if (h == n->repre) {
                        n->dist_in[h_idx] = 0;
                        continue;
                    }

                    ll min_d = INF;
                    auto it_phi_in = n->phi_in.find(h);
                    if (it_phi_in != n->phi_in.end()) {
                        min_d = it_phi_in->second;
                    }

                    
            // 计算 h → n 的最短路径：h → hk → n
            //  h → hk   = h 的 dist_out （你正确！）
            //  hk → n   = n 的 dist_in
            // =================================================================
                    for (int k = 0; k < h_idx; k++) {
                        int hk = n->hubs[k];        // 上层枢纽 hk
                        TreeNode* h_node = treeNodes[h]; // 当前目标枢纽 h

                        // 在 h 的枢纽列表里 找 hk
                        auto it = find(h_node->hubs.begin(), h_node->hubs.end(), hk);
                        if (it != h_node->hubs.end()) {
                            int idx = it - h_node->hubs.begin();

                            // ✅ 完全按照你的正确理解：
                            ll h_to_hk = h_node->dist_out[idx];   // h → hk（h的out！）
                            ll hk_to_n = n->dist_in[k];           // hk → n

                            if (h_to_hk < INF && hk_to_n < INF) {
                                min_d = min(min_d, h_to_hk + hk_to_n);
                            }
                        }
                    }
                    // ===================================================

                    for (int xj : n->acce) {
                        TreeNode* xj_node = treeNodes[xj];
                        TreeNode* h_node = treeNodes[h];
                        if (xj_node->level < h_node->level) continue;

                        ll xj2v = INF;
                        auto it_xjv = n->phi_in.find(xj);
                        if (it_xjv != n->phi_in.end()) {
                            xj2v = it_xjv->second;
                        }
                        if (xj2v == INF) continue;

                        ll h2xj = INF;
                        if (h_node->level <= xj_node->level) {
                            auto it = find(xj_node->hubs.begin(), xj_node->hubs.end(), h);
                            if (it != xj_node->hubs.end()) {
                                int idx = it - xj_node->hubs.begin();
                                h2xj = xj_node->dist_in[idx];
                            }
                        }
                        if (h2xj < INF) {
                            min_d = min(min_d, h2xj + xj2v);
                        }
                    }
                    n->dist_in[h_idx] = min_d;
                }
            }

            for (TreeNode* child : n->children) q.push(child);
        }

        auto end = high_resolution_clock::now();
        hubLabelTimeMs = duration_cast<microseconds>(end - start).count() / 1000.0;
        cout << "  -> Directed hub labeling done! Time: " << hubLabelTimeMs << " ms\n";
    }


    // 无向图枢纽标记（Paper 6.2 标准实现：BFS、单距离、分情况、无查询）
    void buildHubLabelingUndirected() {
        cout << "  -> Building Undirected hub labeling...\n";
        auto start = high_resolution_clock::now();

        if (graph.empty()) return;

        // 从上到下 BFS（祖先先算，正确）
        queue<TreeNode*> q;
        q.push(root);

        while (!q.empty()) {
            TreeNode* n = q.front();
            q.pop();

            n->hubs = n->ancestors;
            n->pos.clear();
            auto add_pos = [&](int u) {
                auto it = find(n->hubs.begin(), n->hubs.end(), u);
                if (it != n->hubs.end()) {
                    n->pos.push_back(it - n->hubs.begin());
                }
                };
            for (int a : n->acce) add_pos(a);
            add_pos(n->repre);

            int hub_num = n->hubs.size();
            n->dist_out.assign(hub_num, INF);
            if (n == root) {
                for (int i = 0; i < hub_num; ++i) {
                    if (n->hubs[i] == n->repre) {
                        n->dist_out[i] = 0;
                    }
                }
            }
            else {
                // -------------------- dist_out --------------------
                for (int h_idx = 0; h_idx < hub_num; ++h_idx) {
                    int h = n->hubs[h_idx];
                    if (h == n->repre) {
                        n->dist_out[h_idx] = 0;
                        continue;
                    }
                    TreeNode* h_node = treeNodes[h];
                    ll min_d = INF;
                    auto it_phi = n->phi.find(h);
                    if (it_phi != n->phi.end()) {
                        min_d = it_phi->second;
                    }

                    // 上层已计算枢纽中转（核心最优路径）
                    for (int k = 0; k < h_idx; k++) {
                        int hk = n->hubs[k];
                        TreeNode* hk_node = treeNodes[hk];
                        auto it = find(h_node->hubs.begin(), h_node->hubs.end(), hk);
                        if (it != h_node->hubs.end()) {
                            int idx = it - h_node->hubs.begin();
                            ll d1 = n->dist_out[k];
                            ll d2 = h_node->dist_out[idx];
                            if (d1 < INF && d2 < INF) {
                                min_d = min(min_d, d1 + d2);
                            }
                        }
                    }
                    for (int xj : n->acce) {
                        TreeNode* xj_node = treeNodes[xj];

                        if (xj_node->level < h_node->level) continue;

                        ll v2xj = INF;
                        auto it_vxj = n->phi.find(xj);
                        if (it_vxj != n->phi.end()) {
                            v2xj = it_vxj->second;
                        }
                        if (v2xj == INF) continue;

                        ll xj2h = INF;
                        if (h_node->level <= xj_node->level) {
                            auto it = find(xj_node->hubs.begin(), xj_node->hubs.end(), h);
                            if (it != xj_node->hubs.end()) {
                                int idx = it - xj_node->hubs.begin();
                                xj2h = xj_node->dist_out[idx];
                            }
                        }
                        if (xj2h < INF) {
                            min_d = min(min_d, v2xj + xj2h);
                        }
                    }
                    n->dist_out[h_idx] = min_d;
                }
            }

            for (TreeNode* child : n->children) q.push(child);
        }

        auto end = high_resolution_clock::now();
        hubLabelTimeMs = duration_cast<microseconds>(end - start).count() / 1000.0;
        cout << "  -> UnDirected hub labeling done! Time: " << hubLabelTimeMs << " ms\n";
    }

    size_t calcSize(TreeNode* n) const {
        if (!n)return 0; size_t s = sizeof(*n);
        s += n->vertices.size() * 4; s += n->ancestors.size() * 4;
        s += n->acce.size() * 4; s += n->accedist.size() * 8;
        s += n->dist_out.size() * 8; s += n->dist_in.size() * 8;
        s += n->pos.size() * 4;
        for (auto c : n->children)s += calcSize(c);
        return s;
    }

public:
    TDHL(const Graphs& g) :graph(g), root(nullptr), treeWidth(0), maxTreeNodeSize(0), rng(random_device{}()) { initFastEdgeCheck(); }
    ~TDHL() { for (auto& kv : treeNodes)delete kv.second; }

    void buildIndex() {
        cout << "\n=== Building TDHL Index ===\n";
        if (graph.empty()) return;

        buildTreeDecomposition();
        if (graph.isDirected) {
            buildHubLabelingDirected();
        }
        else {
            buildHubLabelingUndirected();
        }
        cout << "=== TDHL Index finished ===\n\n";
    }

    int getTreeWidth()const { return treeWidth; }
    int getMaxNodeSize()const { return maxTreeNodeSize; }
    int getNodeCount()const { return treeNodes.size(); }
    string getGraphName()const { return graph.getName(); }
    bool empty()const { return graph.empty(); }
    size_t getIndexSize()const { return calcSize(root); }
    double getTreeDecompTimeMs() const { return treeDecompTimeMs; }
    double getHubLabelTimeMs() const { return hubLabelTimeMs; }

    string getStatistics() const {
        ostringstream oss;
        oss << "Vertices: " << graph.getVertexCount() << "\n";
        oss << "Edges: " << graph.getEdgeCount() << "\n";
        oss << "Tree nodes: " << treeNodes.size() << "\n";
        oss << "Tree width: " << treeWidth << "\n";
        oss << "Max node size: " << maxTreeNodeSize << "\n";
        oss << "Type: " << (graph.isDirected ? "Directed" : "Undirected") << "\n";
        oss << "Tree decomp time: " << fixed << setprecision(2) << treeDecompTimeMs << " ms\n";
        oss << "Hub label time: " << hubLabelTimeMs << " ms\n";
        oss << "Index size: " << getIndexSize() << "B";
        return oss.str();
    }

    string getIndexData() const {
        ostringstream oss;
        oss << "=== " << graph.getName() << " ===\n";
        oss << "VertexCount: " << graph.getVertexCount() << "\n";
        oss << "EdgeCount: " << graph.getEdgeCount() << "\n";
        oss << "TreeWidth: " << treeWidth << "\nNodeCount: " << treeNodes.size() << "\n";
        oss << "GraphType: " << (graph.isDirected ? "DIRECTED" : "UNDIRECTED") << "\n\n";
        oss << "[NODE_DATA]\n";
        for (auto& kv : treeNodes) {
            auto n = kv.second;
            oss << "NODE " << n->id << "\nA:";
            for (int a : n->ancestors)oss << " " << treeNodes.at(a)->repre;

            if (graph.isDirected) {
                oss << "\nDOUT:"; for (auto d : n->dist_out) oss << " " << d;
                oss << "\nDIN:";  for (auto d : n->dist_in)  oss << " " << d;
            }
            else {
                oss << "\nD:"; for (auto d : n->dist_out) oss << " " << d;
            }

            oss << "\nP:"; for (int p : n->pos)oss << " " << p;
            if (!n->acce.empty()) {
                oss << "\nAcce:";
                for (int a : n->acce) oss << " " << a;
            }
            oss << "\n\n";
        }
        return oss.str();
    }
};

class PartitionLoader {
public:
    static bool load(const string& f, vector<OriginalGraph>& parts) {
        cout << "Loading partition file: " << f << "\n";
        ifstream in(f); if (!in)return false;
        string line; int curr = -1;
        while (getline(in, line)) {
            if (line.empty())continue;
            if (line.find("Partition") != string::npos) {
                size_t c = line.find(':'), s = line.find_first_of("0123456789");
                if (s != string::npos && s < c) { string num; while (s < c && isdigit(line[s]))num += line[s++]; curr = stoi(num); if (curr >= parts.size())parts.resize(curr + 1); }
            }
            else if (curr >= 0 && curr < parts.size()) {
                istringstream iss(line); int u, v; double w; if (iss >> u >> v >> w)parts[curr].addEdge(u, v, w);
            }
        }
        cout << "Partitions loaded: " << parts.size() << "\n";
        return true;
    }

    static bool loadOverlay(const string& f, OriginalGraph& g) {
        cout << "Loading overlay graph: " << f << "\n";
        ifstream in(f); if (!in)return false; string line;
        while (getline(in, line)) {
            if (line.empty() || line[0] == '#')continue;
            istringstream iss(line); int u, v; double w; if (iss >> u >> v >> w)g.addEdge(u, v, w);
        }
        cout << "Overlay graph loaded successfully\n";
        return !g.vertices.empty();
    }
};

PartitionResult process(const OriginalGraph& g, int id, bool dir) {
    cout << "Processing partition " << id << "...\n";
    PartitionResult res; res.partitionId = id; res.success = false;
    try {
        Graphs gr; gr.buildFromOriginal(g, "P" + to_string(id), dir);
        TDHL td(gr); td.buildIndex();
        res.treeWidth = td.getTreeWidth();
        res.indexSize = td.getIndexSize();
        res.statistics = td.getStatistics();
        res.indexData = td.getIndexData();
        res.success = true;
        res.treeDecompTimeMs = td.getTreeDecompTimeMs();
        res.hubLabelTimeMs = td.getHubLabelTimeMs();
    }
    catch (...) {}
    cout << "Partition " << id << " done\n";
    g_completed_partitions++;
    lock_guard<mutex> lock(g_print_mutex);
    cout << "✅ Partition " << id << " finished! Progress: "
        << g_completed_partitions << "/" << g_total_valid_partitions << "\n";
    return res;
}

class TDHLQuery {
public:
    bool load(const string& f) { return true; }
    double query(int s, int t) { return 0; }
};

int main() {
    cout << fixed << setprecision(4);
    cout << "\n=========================================\n";
    cout << "TDHL Index Construction Tool Started\n";
    cout << "=========================================\n\n";

    double ch_preprocess_time = 1.0 * (clock() - T) / CLOCKS_PER_SEC;
    cout << "CH Preprocessing... Please wait...\n";
    cout << "CH Preprocessing time: " << ch_preprocess_time << "s\n\n";

    auto total_start = high_resolution_clock::now();

    string typeStr; bool directed = false;
    cout << "Graph type (U/D): "; getline(cin, typeStr);
    directed = (typeStr == "D" || typeStr == "d");
    cout << "Graph type set to: " << (directed ? "Directed" : "Undirected") << "\n\n";

    string partFile, overlayFile;
    cout << "Partition file: "; getline(cin, partFile);
    cout << "Overlay file: "; getline(cin, overlayFile);

    int threads = 0;
    if (!partFile.empty()) {
        string tstr; cout << "Threads: "; getline(cin, tstr);
        if (!tstr.empty())threads = stoi(tstr);
        if (threads <= 0)threads = omp_get_max_threads();
        omp_set_num_threads(threads);
        cout << "Using threads: " << threads << "\n\n";
    }

    cout << "Starting index building...\n\n";
    ofstream idx("tdhl_index.txt"), stat("tdhl_stats.txt");
    if (!idx || !stat)return 1;

    vector<int> widths;
    size_t totalSize = 0;
    double totalTreeDecompMs = 0;
    double totalHubLabelMs = 0;
    int valid_partition_count = 0;
    vector<PartitionResult> allResults;

    if (!partFile.empty()) {
        vector<OriginalGraph> parts;
        PartitionLoader::load(partFile, parts);
        vector<int> valid;
        for (int i = 0; i < parts.size(); i++)if (!parts[i].vertices.empty())valid.push_back(i);
        g_total_valid_partitions = valid.size();
        int totalTask = valid.size();
        vector<PartitionResult> res(totalTask);

        cout << "\nStart parallel processing " << totalTask << " partitions...\n\n";

#pragma omp parallel for
        for (int i = 0; i < totalTask; i++) {
            res[i] = process(parts[valid[i]], valid[i], directed);
        }

        for (auto& r : res) {
            if (r.success) {
                valid_partition_count++;
                widths.push_back(r.treeWidth);
                totalSize += r.indexSize;
                stat << "Partition " << r.partitionId << "\n" << r.statistics << "\n\n";
                idx << r.indexData << "\n";
                totalTreeDecompMs += r.treeDecompTimeMs;
                totalHubLabelMs += r.hubLabelTimeMs;
            }
        }
        allResults = move(res);
    }

    if (!overlayFile.empty()) {
        OriginalGraph og;
        if (PartitionLoader::loadOverlay(overlayFile, og)) {
            Graphs g; g.buildFromOriginal(og, "Overlay", directed);
            TDHL td(g); td.buildIndex();
            stat << "Overlay\n" << td.getStatistics() << "\n\n";
            idx << td.getIndexData() << "\n";
            widths.push_back(td.getTreeWidth());
            totalSize += td.getIndexSize();
            totalTreeDecompMs += td.getTreeDecompTimeMs();
            totalHubLabelMs += td.getHubLabelTimeMs();
        }
    }

    auto total_end = high_resolution_clock::now();
    double total_program_sec = duration_cast<microseconds>(total_end - total_start).count() / 1000000.0;

    double avg_tree = 0, avg_hub = 0;
    if (valid_partition_count > 0) {
        avg_tree = totalTreeDecompMs / valid_partition_count;
        avg_hub = totalHubLabelMs / valid_partition_count;
    }

    cout << "\n=========================================\n";
    cout << "All tasks finished!\n";
    cout << "CH preprocessing time: " << ch_preprocess_time << " s\n";
    cout << "Total program time: " << total_program_sec << " s\n";
    cout << "Valid partitions: " << valid_partition_count << "\n";
    cout << "Avg tree decomp: " << avg_tree << " ms\n";
    cout << "Avg hub label: " << avg_hub << " ms\n";
    cout << "Total tree decomp: " << totalTreeDecompMs << " ms\n";
    cout << "Total hub label: " << totalHubLabelMs << " ms\n";
    cout << "Total index size: " << totalSize << " B\n";
    cout << "=========================================\n\n";

    stat << "\n===== FINAL FULL STATISTICS =====\n";
    stat << "CH preprocessing time: " << ch_preprocess_time << " seconds\n";
    stat << "Total program running time: " << total_program_sec << " seconds\n";
    stat << "Valid partition count: " << valid_partition_count << "\n";
    stat << "Average tree decomposition: " << avg_tree << " ms per valid partition\n";
    stat << "Average hub labeling: " << avg_hub << " ms per valid partition\n";
    stat << "Total tree decomposition time: " << fixed << setprecision(2) << totalTreeDecompMs << " ms\n";
    stat << "Total hub labeling time: " << totalHubLabelMs << " ms\n";
    stat << "Total index size: " << totalSize << " B\n";

    idx.close();
    stat.close();

    cout << "Program completed successfully!\n";
    system("pause");
    return 0;
}