﻿#ifndef __G_GRAPH_H__
#define __G_GRAPH_H__

#include <vector>
#include <stdio.h>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <string>

using namespace std;

#include "../share/Utility.h"
#include "../Assemble/A_Graph.h"

#include "G_Node.h"
#include "Edge_sort.h"
#include "PushRelabel.h"

// 前向声明，避免循环包含
class NaturalCutPunchPlus;

// Configuration for natural cut method
#ifndef NATURAL_CUT_METHOD
#define NATURAL_CUT_METHOD 1  // 0 = Original, 1 = PUNCH+
#endif

struct edge_cncted_comp {
    list<NodeID> component; // here the node ID is the contracted node ID
    list<NodeID> children; // the node ID is actually size_t, position of its children
    NodeID parent; // the node ID is actually size_t, position of its parent
    NodeID neighbor_id_in_parent;
    NodeSize subtree_size; // zero means the tree node is removed or merged with parent
};

class G_Graph {
public:

    G_Graph() {
        // by default
        DNCC = 2;
        DNCF = 10;
        punch_plus_cutter = nullptr;
        natural_cut_method = NATURAL_CUT_METHOD;
    }

    ~G_Graph() {
        if (punch_plus_cutter) {
            delete punch_plus_cutter;
        }
    }

    vector<G_Node>& get_node_list() {
        return this->node_list;
    }

    const vector<G_Node>& get_node_list() const {
        return this->node_list;
    }

    vector<G_Edge>& get_edge_list() {
        return this->edge_list;
    }

    const vector<G_Edge>& get_edge_list() const {
        return this->edge_list;
    }

    NodeID contract_id(NodeID nid) const {
        return this->contract_to[nid];
    }

    vector<NodeID>& get_cont_node(NodeID nid) {
        return this->contract_node_list[nid];
    }

    const vector<NodeID>& get_cont_node(NodeID nid) const {
        return this->contract_node_list[nid];
    }

    // 新增：获取完整的contract_node_list（只读）
    const vector<vector<NodeID>>& get_contract_node_list() const {
        return this->contract_node_list;
    }

    // 新增：获取contract_to数组（只读）
    const vector<NodeID>& get_contract_to() const {
        return this->contract_to;
    }

    // 新增：获取删除的压缩节点列表（只读）
    const vector<NodeID>& get_del_cnt_node() const {
        return this->del_cnt_node;
    }

    // 新增：获取对称边ID数组（只读）
    const vector<NodeID>& get_sym_id() const {
        return this->sym_id;
    }

    G_Edge* const sym_edge(G_Edge* const e) {
        return &this->edge_list[this->sym_id[e->get_id()]];
    }

    EdgeID const sym_edge_id(EdgeID eid) {
        return this->sym_id[eid];
    }

    // 新增：获取压缩节点的原始节点数量
    NodeSize get_contracted_node_size(NodeID compressed_id) const {
        return static_cast<NodeSize>(contract_node_list[compressed_id].size());
    }

    // 新增：检查压缩节点是否为空
    bool is_contracted_node_empty(NodeID compressed_id) const {
        return contract_node_list[compressed_id].empty();
    }

    // 新增：获取有效压缩节点数量
    size_t get_valid_contracted_node_count() const {
        size_t count = 0;
        for (size_t i = 0; i < contract_node_list.size(); ++i) {
            if (!contract_node_list[i].empty()) {
                ++count;
            }
        }
        return count;
    }

    VERBOSE(
        vector<NodeID> get_del_node() {
        return this->del_cnt_node;
    }
    )

        /////////////////////////////main methods////////////////////////////

        void read_graph(string co_path, string gr_path);

    void dfs_tree(NodeID start, vector<bool>& edge_removed, NodeSize size_lim);

    void bfs_tree(NodeID start, vector<bool>& node_added, NodeSize size_lim) {
        //////////////////////////
    }

    void two_cuts_edge_class(vector<bool>& edge_in_fi,
        vector<vector<NodeID>>& edge_equl_cls);

    void cnt_two_cuts(const vector<vector<EdgeID>>& edge_classes,
        NodeSize sz_lim);

    void cnt_two_degree_path(NodeSize sz_lim);

    // Unified natural cut detection interface
    void find_natural_cuts(bool natural_cuts[], NodeSize sz_lim) {
#if NATURAL_CUT_METHOD == 0
        find_natural_cuts_original(natural_cuts, sz_lim);
#else
        find_natural_cuts_improved(natural_cuts, sz_lim);
#endif
    }

    void cnt_natural_cuts(bool natural_cuts[]);

    void convert_n_output(string r_path);

    void cnt_one_cuts(const vector<EdgeID>& one_cut_edges, NodeSize sz_lim);

    // Natural cut method selection
    void set_natural_cut_method(int method) {
        natural_cut_method = method;
    }

    // Get current method
    int get_natural_cut_method() const {
        return natural_cut_method;
    }

    // 设置自然割参数
    void set_natural_cut_parameters(unsigned int dncc, unsigned int dncf) {
        DNCC = dncc;
        DNCF = dncf;
    }

    // 获取自然割参数
    void get_natural_cut_parameters(unsigned int& dncc, unsigned int& dncf) const {
        dncc = DNCC;
        dncf = DNCF;
    }

public:
    // natural cuts parameters
    unsigned int DNCC;
    unsigned int DNCF;

private:
    // basic
    vector<G_Node> node_list;
    vector<G_Edge> edge_list;
    // record symmetric edge id
    vector<NodeID> sym_id;

    // deal with node contraction
    vector<NodeID> contract_to;
    vector<vector<NodeID>> contract_node_list;
    vector<NodeID> del_cnt_node; // record delelte contracted nodes, 
    // also available contract slots

    // Natural cut detection method
    int natural_cut_method;
    NaturalCutPunchPlus* punch_plus_cutter;  // 这里使用前向声明的类指针

    //////////////////////////main Internal Methods////////////////////////////

    void fill_b_bits(vector<bool>& edge_removed,
        vector<Bits>& b_bit_list, unsigned int b);

    void classify_edge(const vector<Bits>& b_bit_list,
        vector<vector<EdgeID>>& edge_classes);

    void mark_node_vis(NodeID nid, vector<bool>& mark_list);

    void contract_nodes(const vector<NodeID>& node_list);

    void contract_nodes(NodeID m, NodeID n);

    unsigned int node_degree(NodeID n);

    NodeSize cal_node_size(const vector<NodeID>& node_list);

    NodeSize cal_comp_size(const list<NodeID>& cnode_list);

    NodeID next_center(bool node_in_core[]);

    void mark_node_vis(NodeID nid, bool* mark_list);

    void natural_st_cuts_from_s(bool* natural_cuts, const deque<NodeID>& core,
        const vector<NodeID>& between_nodes);

    void natural_st_cuts_from_t(bool* natural_cuts, const deque<NodeID>& core,
        const vector<NodeID>& between_nodes);

    void contract_nodes(const deque<NodeID>& node_list);

    size_t build_component_tree(const vector<EdgeID>& one_cut_edges,
        vector<edge_cncted_comp>& component_tree);

    NodeSize fill_subtree_size(vector<edge_cncted_comp>& component_tree, size_t root_p);

    void cnt_proper_tree_components(vector<edge_cncted_comp>& component_tree, size_t root_p,
        NodeSize sz_lim);

    void link_component(vector<edge_cncted_comp>& component_tree, map<NodeID, size_t>&
        comp_cnodes_to_pos, size_t search_pos, size_t parent_pos);

    NodeID contract_cnodes(const list<NodeID>& cnode_list);

    NodeID contract_child_to_parent(NodeID child, NodeID parent);

    NodeID contract_subtree(vector<edge_cncted_comp>& component_tree, size_t root_pos);

    void find_all_comp(vector<edge_cncted_comp>& component_tree, size_t root_pos,
        list<NodeID>& all_comp);

    // Original natural cut method
    void find_natural_cuts_original(bool natural_cuts[], NodeSize sz_lim);

    // PUNCH+ improved natural cut method
    void find_natural_cuts_improved(bool natural_cuts[], NodeSize sz_lim);
};

#endif // __G_GRAPH_H__