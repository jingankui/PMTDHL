#ifndef __PUSH_RELABEL_H__
#define __PUSH_RELABEL_H__

// ����ͷ�ļ�����������

#include <cmath>
#include <vector>
#include <iostream>
#include <queue>

using namespace std;

typedef long long LL;

// ��Edge�ṹ�嶨���Ƶ�ǰ��
struct Edge {
    int from, to, cap, flow, index;
    Edge(int from, int to, int cap, int flow, int index) :
        from(from), to(to), cap(cap), flow(flow), index(index) {
    }
};

struct Rv_Graph {
    int N;
    vector<vector<Edge> > G;

    Rv_Graph(int N) : N(N), G(N) {}

    void add_reverse_edge(const Edge& e) {
        G[e.to].push_back(Edge(e.to, e.from, e.cap, e.flow, e.index));
    }
};

class PushRelabel {
public:
    PushRelabel(int N) : N(N), G(N), excess(N), dist(N), active(N), count(2 * N) {}

    void AddEdge(int from, int to, int cap) {
        G[from].push_back(Edge(from, to, cap, 0, G[to].size()));
        if (from == to) G[from].back().index++;
        G[to].push_back(Edge(to, from, 0, 0, G[from].size() - 1));
    }

    LL GetMaxFlow(int s, int t) {
        count[0] = N - 1;
        count[N] = 1;
        dist[s] = N;
        active[s] = active[t] = true;
        for (size_t i = 0; i < G[s].size(); i++) {
            excess[s] += G[s][i].cap;
            Push(G[s][i]);
        }

        while (!Q.empty()) {
            int v = Q.front();
            Q.pop();
            active[v] = false;
            Discharge(v);
        }

        LL totflow = 0;
        for (size_t i = 0; i < G[s].size(); i++) totflow += G[s][i].flow;
        return totflow;
    }

    // �ṩ����ͼ�Ĺ��з���
    const vector<vector<Edge> >& getGraph() const { return G; }
    const vector<Edge>& getNodeEdges(int node) const { return G[node]; }
    int getNodeCount() const { return N; }

    // ��������ȡ�ߵ���Ϣ
    int getEdgeFrom(const Edge& e) const { return e.from; }
    int getEdgeTo(const Edge& e) const { return e.to; }
    int getEdgeCap(const Edge& e) const { return e.cap; }
    int getEdgeFlow(const Edge& e) const { return e.flow; }

private:
    int N;
    vector<vector<Edge> > G;
    vector<LL> excess;
    vector<int> dist, active, count;
    queue<int> Q;

    void Enqueue(int v) {
        if (!active[v] && excess[v] > 0) { active[v] = true; Q.push(v); }
    }

    void Push(Edge& e) {
        int amt = int(min(excess[e.from], LL(e.cap - e.flow)));
        if (dist[e.from] <= dist[e.to] || amt == 0) return;
        e.flow += amt;
        G[e.to][e.index].flow -= amt;
        excess[e.to] += amt;
        excess[e.from] -= amt;
        Enqueue(e.to);
    }

    void Gap(int k) {
        for (int v = 0; v < N; v++) {
            if (dist[v] < k) continue;
            count[dist[v]]--;
            dist[v] = max(dist[v], N + 1);
            count[dist[v]]++;
            Enqueue(v);
        }
    }

    void Relabel(int v) {
        count[dist[v]]--;
        dist[v] = 2 * N;
        for (size_t i = 0; i < G[v].size(); i++)
            if (G[v][i].cap - G[v][i].flow > 0)
                dist[v] = min(dist[v], dist[G[v][i].to] + 1);
        count[dist[v]]++;
        Enqueue(v);
    }

    void Discharge(int v) {
        for (size_t i = 0; excess[v] > 0 && i < G[v].size(); i++) Push(G[v][i]);
        if (excess[v] > 0) {
            if (count[dist[v]] == 1)
                Gap(dist[v]);
            else
                Relabel(v);
        }
    }
};

#endif // __PUSH_RELABEL_H__