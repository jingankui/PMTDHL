﻿#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <cmath>
#include <algorithm>
#include <queue>
#include <iomanip>
#include <limits>
#include <thread>
#include <mutex>
#include <atomic>
#include <future>
#include <chrono>
#include <omp.h>
#include "../Utils.h"

using namespace std;

const double INF = numeric_limits<double>::max();

// 自定义哈希函数用于 pair<long long, long long>
struct PairHash {
    size_t operator()(const pair<long long, long long>& p) const {
        // 将两个long long组合成一个哈希值
        size_t h1 = hash<long long>{}(p.first);
        size_t h2 = hash<long long>{}(p.second);
        // 使用一个简单的组合方法
        return h1 ^ (h2 << 1);
    }
};

// 自定义相等比较函数
struct PairEqual {
    bool operator()(const pair<long long, long long>& a,
        const pair<long long, long long>& b) const {
        return a.first == b.first && a.second == b.second;
    }
};

// Dijkstra缓存类
class DijkstraCache {
private:
    // 使用自定义哈希和相等比较
    unordered_map<pair<long long, long long>, double, PairHash, PairEqual> cache;
    mutex cache_mtx;

    pair<long long, long long> makeKey(long long a, long long b) {
        return a < b ? make_pair(a, b) : make_pair(b, a);
    }

public:
    double get(long long a, long long b) {
        auto key = makeKey(a, b);
        lock_guard<mutex> lock(cache_mtx);
        auto it = cache.find(key);
        if (it != cache.end()) {
            return it->second;
        }
        return INF;  // 表示缓存未命中
    }

    void put(long long a, long long b, double value) {
        auto key = makeKey(a, b);
        lock_guard<mutex> lock(cache_mtx);
        cache[key] = value;
    }

    size_t size() {
        lock_guard<mutex> lock(cache_mtx);
        return cache.size();
    }

    void clear() {
        lock_guard<mutex> lock(cache_mtx);
        cache.clear();
    }
};

// 边信息结构体
struct EdgeInfo {
    long long src;
    long long dst;
    double weight;

    bool operator<(const EdgeInfo& other) const {
        if (src != other.src) return src < other.src;
        return dst < other.dst;
    }

    bool operator==(const EdgeInfo& other) const {
        return src == other.src && dst == other.dst;
    }
};

// 分区信息
struct PartitionInfo {
    vector<long long> nodes;
    unordered_set<long long> nodeSet;
    vector<EdgeInfo> internalEdges;
    vector<EdgeInfo> boundaryEdges;
    unordered_set<long long> boundaryNodes;
    vector<vector<pair<long long, double>>> adj;
    int connectedComponents;
    vector<vector<long long>> components;
    mutable mutex partition_mtx;

    // 默认构造函数
    PartitionInfo() : connectedComponents(0) {}

    // 移动构造函数
    PartitionInfo(PartitionInfo&& other) noexcept
        : nodes(move(other.nodes)),
        nodeSet(move(other.nodeSet)),
        internalEdges(move(other.internalEdges)),
        boundaryEdges(move(other.boundaryEdges)),
        boundaryNodes(move(other.boundaryNodes)),
        adj(move(other.adj)),
        connectedComponents(other.connectedComponents),
        components(move(other.components)) {
    }

    // 移动赋值运算符
    PartitionInfo& operator=(PartitionInfo&& other) noexcept {
        if (this != &other) {
            nodes = move(other.nodes);
            nodeSet = move(other.nodeSet);
            internalEdges = move(other.internalEdges);
            boundaryEdges = move(other.boundaryEdges);
            boundaryNodes = move(other.boundaryNodes);
            adj = move(other.adj);
            connectedComponents = other.connectedComponents;
            components = move(other.components);
        }
        return *this;
    }
};

// 全局图结构 - 使用共享指针来避免拷贝问题
class Graph {
private:
    struct GraphData {
        unordered_map<long long, unordered_map<long long, double>> adjacency;
        unordered_set<long long> allNodes;
        mutable mutex graph_mtx;

        GraphData() = default;

        // 禁用拷贝，允许移动
        GraphData(const GraphData&) = delete;
        GraphData& operator=(const GraphData&) = delete;

        GraphData(GraphData&& other) noexcept
            : adjacency(move(other.adjacency)),
            allNodes(move(other.allNodes)) {
        }
    };

    shared_ptr<GraphData> data;

public:
    Graph() : data(make_shared<GraphData>()) {}

    // 移动构造函数
    Graph(Graph&& other) noexcept : data(move(other.data)) {}

    // 移动赋值运算符
    Graph& operator=(Graph&& other) noexcept {
        if (this != &other) {
            data = move(other.data);
        }
        return *this;
    }

    // 从文件构造
    static Graph createFromFile(const string& filename) {
        Graph graph;
        ifstream file(filename);

        if (!file.is_open()) {
            cerr << "错误：无法打开原始图文件: " << filename << endl;
            return graph;
        }

        string line;
        int edgeCount = 0;

        while (getline(file, line)) {
            if (line.empty() || line[0] == '#') continue;

            istringstream iss(line);
            char type;
            long long src, dst;
            double weight;

            if (iss >> type >> src >> dst >> weight) {
                if (type == 'a') {
                    graph.addEdge(src, dst, weight);
                    edgeCount++;
                }
            }
        }

        cout << "✓ 从原始图读取了 " << edgeCount << " 条边" << endl;
        file.close();
        return graph;
    }

    // 并行从文件构造
    static Graph createFromFileParallel(const string& filename) {
        Graph graph;
        ifstream file(filename);

        if (!file.is_open()) {
            cerr << "错误：无法打开原始图文件: " << filename << endl;
            return graph;
        }

        vector<string> lines;
        string line;

        // 先读取所有行
        while (getline(file, line)) {
            if (!line.empty() && line[0] != '#') {
                lines.push_back(line);
            }
        }
        file.close();

        cout << "读取了 " << lines.size() << " 行数据，开始并行处理..." << endl;

        // 并行处理每一行
        atomic<int> edgeCount{ 0 };

#pragma omp parallel for
        for (int i = 0; i < static_cast<int>(lines.size()); i++) {
            istringstream iss(lines[i]);
            char type;
            long long src, dst;
            double weight;

            if (iss >> type >> src >> dst >> weight) {
                if (type == 'a') {
                    graph.addEdge(src, dst, weight);
                    edgeCount++;
                }
            }

            // 进度显示
            if (i % 100000 == 0 && i > 0) {
#pragma omp critical
                {
                    cout << "已处理 " << i << "/" << lines.size()
                        << " 行 (" << (i * 100 / lines.size()) << "%)" << endl;
                }
            }
        }

        cout << "✓ 从原始图并行读取了 " << edgeCount << " 条边" << endl;
        return graph;
    }

    void addEdge(long long u, long long v, double w) {
        lock_guard<mutex> lock(data->graph_mtx);
        data->adjacency[u][v] = w;
        data->adjacency[v][u] = w;  // 假设是无向图
        data->allNodes.insert(u);
        data->allNodes.insert(v);
    }

    double getWeight(long long u, long long v) const {
        lock_guard<mutex> lock(data->graph_mtx);
        auto it1 = data->adjacency.find(u);
        if (it1 != data->adjacency.end()) {
            auto it2 = it1->second.find(v);
            if (it2 != it1->second.end()) {
                return it2->second;
            }
        }
        return INF;
    }

    // 获取邻接列表（线程安全）
    vector<pair<long long, double>> getNeighbors(long long u) const {
        lock_guard<mutex> lock(data->graph_mtx);
        auto it = data->adjacency.find(u);
        if (it != data->adjacency.end()) {
            vector<pair<long long, double>> neighbors;
            neighbors.reserve(it->second.size());
            for (const auto& kv : it->second) {
                neighbors.emplace_back(kv.first, kv.second);
            }
            return neighbors;
        }
        return {};
    }

    // 获取所有节点
    unordered_set<long long> getAllNodes() const {
        lock_guard<mutex> lock(data->graph_mtx);
        return data->allNodes;
    }

    // 获取节点数量
    size_t getNodeCount() const {
        lock_guard<mutex> lock(data->graph_mtx);
        return data->allNodes.size();
    }

    // 获取边数量
    size_t getEdgeCount() const {
        lock_guard<mutex> lock(data->graph_mtx);
        size_t count = 0;
        for (const auto& kv : data->adjacency) {
            count += kv.second.size();
        }
        return count / 2;  // 因为是无向图，每条边被记录了两次
    }
};

// 读取分区后的节点文件
vector<PartitionInfo> readPartitionedNodes(const string& filename) {
    vector<PartitionInfo> partitions;
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "错误：无法打开分区文件: " << filename << endl;
        return partitions;
    }

    string line;
    PartitionInfo currentPartition;
    bool inPartition = false;
    int partitionCount = 0;

    while (getline(file, line)) {
        if (line.empty()) continue;

        line.erase(0, line.find_first_not_of(" \t"));
        line.erase(line.find_last_not_of(" \t") + 1);

        if (line.find("partition") == 0) {
            if (inPartition && !currentPartition.nodes.empty()) {
                partitions.push_back(move(currentPartition));
                partitionCount++;
            }

            currentPartition = PartitionInfo();
            inPartition = true;
            continue;
        }

        if (!inPartition) continue;

        istringstream iss(line);
        long long nodeId;
        string coordinateStr;

        if (iss >> nodeId >> coordinateStr) {
            currentPartition.nodes.push_back(nodeId);
            currentPartition.nodeSet.insert(nodeId);
        }
    }

    if (inPartition && !currentPartition.nodes.empty()) {
        partitions.push_back(move(currentPartition));
        partitionCount++;
    }

    cout << "✓ 读取了 " << partitionCount << " 个分区" << endl;

    for (int i = 0; i < partitions.size(); i++) {
        cout << "  分区 " << i << ": " << partitions[i].nodes.size() << " 个节点" << endl;
    }

    file.close();
    return partitions;
}

// 并行分离内部边和边界边
void separateEdgesParallel(vector<PartitionInfo>& partitions, const Graph& originalGraph) {
    int numPartitions = static_cast<int>(partitions.size());

    // 构建节点到分区的映射
    unordered_map<long long, int> nodeToPartition;
    for (int p = 0; p < numPartitions; p++) {
        for (long long node : partitions[p].nodes) {
            nodeToPartition[node] = p;
        }
    }

    // 并行处理每个分区
    int totalInternalEdges = 0;
    int totalBoundaryEdges = 0;

#pragma omp parallel for reduction(+:totalInternalEdges, totalBoundaryEdges)
    for (int p = 0; p < numPartitions; p++) {
        auto& partition = partitions[p];

        // 构建节点ID到索引的映射
        unordered_map<long long, int> nodeIndexMap;
        for (int i = 0; i < static_cast<int>(partition.nodes.size()); i++) {
            nodeIndexMap[partition.nodes[i]] = i;
        }

        // 初始化邻接表
        partition.adj.resize(partition.nodes.size());

        // 用于去重的集合
        set<pair<long long, long long>> addedInternalEdges;
        set<pair<long long, long long>> addedBoundaryEdges;

        // 遍历分区内所有节点
        for (int i = 0; i < static_cast<int>(partition.nodes.size()); i++) {
            long long node1 = partition.nodes[i];

            // 获取邻居
            auto neighbors = originalGraph.getNeighbors(node1);

            for (const auto& neighbor : neighbors) {
                long long node2 = neighbor.first;
                double weight = neighbor.second;

                // 确定node2属于哪个分区
                auto partitionIt = nodeToPartition.find(node2);
                if (partitionIt == nodeToPartition.end()) continue;

                int node2Partition = partitionIt->second;

                // 确保节点ID有序
                long long smaller = min(node1, node2);
                long long larger = max(node1, node2);
                pair<long long, long long> edgeKey = { smaller, larger };

                if (node2Partition == p) {
                    // 同一分区内：内部边
                    if (addedInternalEdges.find(edgeKey) == addedInternalEdges.end()) {
                        EdgeInfo edge;
                        edge.src = smaller;
                        edge.dst = larger;
                        edge.weight = weight;

                        // 使用局部锁
                        {
                            lock_guard<mutex> lock(partition.partition_mtx);
                            partition.internalEdges.push_back(edge);
                        }

                        addedInternalEdges.insert(edgeKey);

                        // 添加到邻接表
                        int idx1 = nodeIndexMap[node1];
                        int idx2 = nodeIndexMap[node2];
                        partition.adj[idx1].push_back({ node2, weight });
                        partition.adj[idx2].push_back({ node1, weight });
                    }
                }
                else {
                    // 不同分区：边界边
                    if (addedBoundaryEdges.find(edgeKey) == addedBoundaryEdges.end()) {
                        EdgeInfo edge;
                        edge.src = smaller;
                        edge.dst = larger;
                        edge.weight = weight;

                        // 使用局部锁
                        {
                            lock_guard<mutex> lock(partition.partition_mtx);
                            partition.boundaryEdges.push_back(edge);
                        }

                        addedBoundaryEdges.insert(edgeKey);

                        // 标记边界节点
                        {
                            lock_guard<mutex> lock(partition.partition_mtx);
                            partition.boundaryNodes.insert(node1);
                        }
                    }
                }
            }
        }

        totalInternalEdges += static_cast<int>(partition.internalEdges.size());
        totalBoundaryEdges += static_cast<int>(partition.boundaryEdges.size());

#pragma omp critical
        {
            cout << "  分区 " << p << ": " << partition.internalEdges.size()
                << " 条内部边, " << partition.boundaryEdges.size()
                << " 条边界边, " << partition.boundaryNodes.size()
                << " 个边界节点" << endl;
        }
    }

    // 后处理：标记其他分区的边界节点
#pragma omp parallel for
    for (int p = 0; p < numPartitions; p++) {
        auto& partition = partitions[p];
        for (const auto& edge : partition.boundaryEdges) {
            long long otherNode = (partition.nodeSet.count(edge.src)) ? edge.dst : edge.src;

            auto it = nodeToPartition.find(otherNode);
            if (it != nodeToPartition.end()) {
                int otherPartition = it->second;
                if (otherPartition != p) {
                    lock_guard<mutex> lock(partitions[otherPartition].partition_mtx);
                    partitions[otherPartition].boundaryNodes.insert(otherNode);
                }
            }
        }
    }

    cout << "✓ 总共找到 " << totalInternalEdges << " 条内部边" << endl;
    cout << "✓ 总共找到 " << totalBoundaryEdges << " 条边界边" << endl;
}

// 双向Dijkstra算法（优化版）
double bidirectionalDijkstra(const Graph& graph, long long src, long long dst, DijkstraCache* cache = nullptr) {
    if (src == dst) return 0.0;

    // 检查缓存
    if (cache) {
        double cached = cache->get(src, dst);
        if (cached < INF) {
            return cached;
        }
    }

    // 如果两个节点直接相连，直接返回权重
    double directWeight = graph.getWeight(src, dst);
    if (directWeight < INF) {
        if (cache) cache->put(src, dst, directWeight);
        return directWeight;
    }

    // 前向和后向优先队列
    priority_queue<pair<double, long long>,
        vector<pair<double, long long>>,
        greater<pair<double, long long>>> forwardPQ, backwardPQ;

    // 前向和后向距离映射
    unordered_map<long long, double> forwardDist, backwardDist;
    unordered_map<long long, double> forwardClosed, backwardClosed;

    // 初始化
    forwardDist[src] = 0.0;
    backwardDist[dst] = 0.0;
    forwardPQ.push({ 0.0, src });
    backwardPQ.push({ 0.0, dst });

    double bestDistance = INF;
    long long meetingNode = -1;

    // 双向搜索
    while (!forwardPQ.empty() && !backwardPQ.empty()) {
        // 前向搜索一步
        if (!forwardPQ.empty()) {
            auto [fDist, fNode] = forwardPQ.top();
            forwardPQ.pop();

            if (fDist > forwardDist[fNode]) continue;

            // 检查是否在反向闭集中
            if (backwardClosed.find(fNode) != backwardClosed.end()) {
                double totalDist = fDist + backwardClosed[fNode];
                if (totalDist < bestDistance) {
                    bestDistance = totalDist;
                    meetingNode = fNode;
                }
            }

            forwardClosed[fNode] = fDist;

            // 如果当前距离已经超过最佳距离，可以停止
            if (fDist > bestDistance) break;

            // 扩展邻居
            auto neighbors = graph.getNeighbors(fNode);
            for (const auto& neighbor : neighbors) {
                long long v = neighbor.first;
                double weight = neighbor.second;
                double newDist = fDist + weight;

                if (forwardDist.find(v) == forwardDist.end() || newDist < forwardDist[v]) {
                    forwardDist[v] = newDist;
                    forwardPQ.push({ newDist, v });
                }
            }
        }

        // 后向搜索一步
        if (!backwardPQ.empty()) {
            auto [bDist, bNode] = backwardPQ.top();
            backwardPQ.pop();

            if (bDist > backwardDist[bNode]) continue;

            // 检查是否在前向闭集中
            if (forwardClosed.find(bNode) != forwardClosed.end()) {
                double totalDist = bDist + forwardClosed[bNode];
                if (totalDist < bestDistance) {
                    bestDistance = totalDist;
                    meetingNode = bNode;
                }
            }

            backwardClosed[bNode] = bDist;

            // 如果当前距离已经超过最佳距离，可以停止
            if (bDist > bestDistance) break;

            // 扩展邻居
            auto neighbors = graph.getNeighbors(bNode);
            for (const auto& neighbor : neighbors) {
                long long v = neighbor.first;
                double weight = neighbor.second;
                double newDist = bDist + weight;

                if (backwardDist.find(v) == backwardDist.end() || newDist < backwardDist[v]) {
                    backwardDist[v] = newDist;
                    backwardPQ.push({ newDist, v });
                }
            }
        }
    }

    // 保存到缓存
    if (cache && bestDistance < INF) {
        cache->put(src, dst, bestDistance);
    }

    return bestDistance;
}

// 并行计算连通分量
void calculateConnectedComponents(PartitionInfo& partition) {
    int nodeCount = static_cast<int>(partition.nodes.size());
    if (nodeCount == 0) {
        partition.connectedComponents = 0;
        return;
    }

    unordered_map<long long, int> nodeIndexMap;
    for (int i = 0; i < nodeCount; i++) {
        nodeIndexMap[partition.nodes[i]] = i;
    }

    vector<bool> visited(nodeCount, false);
    int componentCount = 0;

    for (int i = 0; i < nodeCount; i++) {
        if (!visited[i]) {
            componentCount++;
            vector<long long> currentComponent;

            queue<int> q;
            q.push(i);
            visited[i] = true;
            currentComponent.push_back(partition.nodes[i]);

            while (!q.empty()) {
                int currentIdx = q.front();
                q.pop();

                for (const auto& neighbor : partition.adj[currentIdx]) {
                    long long neighborId = neighbor.first;
                    int neighborIdx = nodeIndexMap[neighborId];

                    if (!visited[neighborIdx]) {
                        visited[neighborIdx] = true;
                        q.push(neighborIdx);
                        currentComponent.push_back(neighborId);
                    }
                }
            }

            lock_guard<mutex> lock(partition.partition_mtx);
            partition.components.push_back(currentComponent);
        }
    }

    partition.connectedComponents = componentCount;
}

// 并行计算所有分区的连通分量
void calculateAllComponentsParallel(vector<PartitionInfo>& partitions) {
    cout << "并行计算连通分量..." << endl;

    int totalComponents = 0;

#pragma omp parallel for reduction(+:totalComponents)
    for (int i = 0; i < static_cast<int>(partitions.size()); i++) {
        calculateConnectedComponents(partitions[i]);
        totalComponents += partitions[i].connectedComponents;

#pragma omp critical
        {
            cout << "  分区 " << i << ": " << partitions[i].connectedComponents
                << " 个连通分量" << endl;
        }
    }

    cout << "✓ 总连通分量数: " << totalComponents << endl;
}

// 在分区内运行Dijkstra算法计算到所有节点的最短路径
vector<double> runDijkstraInPartition(const PartitionInfo& partition,
    long long sourceNode,
    const unordered_map<long long, int>& nodeIndexMap) {

    auto it = nodeIndexMap.find(sourceNode);
    if (it == nodeIndexMap.end()) {
        return vector<double>();
    }

    int srcIdx = it->second;
    int nodeCount = static_cast<int>(partition.nodes.size());

    vector<double> dist(nodeCount, INF);
    vector<bool> visited(nodeCount, false);

    // 使用优先队列
    priority_queue<pair<double, int>,
        vector<pair<double, int>>,
        greater<pair<double, int>>> pq;

    dist[srcIdx] = 0.0;
    pq.push({ 0.0, srcIdx });

    while (!pq.empty()) {
        auto [currentDist, u] = pq.top();
        pq.pop();

        if (visited[u]) continue;
        visited[u] = true;

        // 遍历所有邻居
        for (const auto& neighbor : partition.adj[u]) {
            long long vId = neighbor.first;
            double weight = neighbor.second;

            auto vit = nodeIndexMap.find(vId);
            if (vit == nodeIndexMap.end()) continue;

            int vIdx = vit->second;
            double newDist = currentDist + weight;

            if (newDist < dist[vIdx]) {
                dist[vIdx] = newDist;
                pq.push({ newDist, vIdx });
            }
        }
    }

    return dist;
}

// 优化版覆盖图构建函数
void buildCoverGraphOptimized(const vector<PartitionInfo>& partitions,
    const Graph& originalGraph,
    const string& outputFilename) {

    auto startTime = chrono::high_resolution_clock::now();

    cout << "开始构建覆盖图（优化版）..." << endl;
    cout << "使用分区内Dijkstra算法，大幅减少计算量..." << endl;

    ofstream outFile(outputFilename);

    if (!outFile.is_open()) {
        cerr << "错误：无法创建覆盖图文件: " << outputFilename << endl;
        return;
    }

    outFile << fixed << setprecision(6);
    outFile << "======================================================" << endl;
    outFile << "覆盖图（由边界边构成）" << endl;
    outFile << "======================================================" << endl;

    // 第一部分：原始边界边
    outFile << "\n第一部分：原始边界边（连接不同分区的边）" << endl;
    outFile << "------------------------------------------------------" << endl;

    int totalBoundaryEdges = 0;
    set<pair<long long, long long>> addedEdges;
    mutex addedEdgesMtx;

    // 输出原始边界边（去重）
    for (int p = 0; p < static_cast<int>(partitions.size()); p++) {
        const auto& partition = partitions[p];
        for (const auto& edge : partition.boundaryEdges) {
            long long smaller = min(edge.src, edge.dst);
            long long larger = max(edge.src, edge.dst);
            pair<long long, long long> edgeKey = { smaller, larger };

            lock_guard<mutex> lock(addedEdgesMtx);
            if (addedEdges.insert(edgeKey).second) {
                totalBoundaryEdges++;
                outFile << smaller << " " << larger << " " << edge.weight << endl;
            }
        }
    }

    outFile << "原始边界边总数: " << totalBoundaryEdges << endl;

    // 第二部分：同一分区内边界节点之间的边
    outFile << "\n\n第二部分：同一分区内边界节点之间的边" << endl;
    outFile << "------------------------------------------------------" << endl;

    int totalIntraPartitionEdges = 0;
    int totalCalculations = 0;

    mutex outputMtx;

    // 用于进度显示
    atomic<int> completedPartitions{ 0 };
    int totalPartitions = static_cast<int>(partitions.size());

    // 并行处理每个分区
#pragma omp parallel for schedule(dynamic)
    for (int p = 0; p < totalPartitions; p++) {
        const auto& partition = partitions[p];

        // 进度显示
        completedPartitions++;
        cout << "处理分区 " << p << " (" << completedPartitions << "/"
            << totalPartitions << "): "
            << partition.boundaryNodes.size() << " 个边界节点" << endl;

        if (partition.boundaryNodes.size() < 2) {
            continue;  // 至少需要2个边界节点才需要计算
        }

        // 构建节点ID到索引的映射
        unordered_map<long long, int> nodeIndexMap;
        for (int i = 0; i < static_cast<int>(partition.nodes.size()); i++) {
            nodeIndexMap[partition.nodes[i]] = i;
        }

        // 将边界节点转为vector以便遍历
        vector<long long> boundaryNodesVec(partition.boundaryNodes.begin(),
            partition.boundaryNodes.end());

        // 为每个边界节点计算单源最短路径
        for (int i = 0; i < static_cast<int>(boundaryNodesVec.size()); i++) {
            long long sourceNode = boundaryNodesVec[i];

            // 在分区内运行Dijkstra算法
            auto distances = runDijkstraInPartition(partition, sourceNode, nodeIndexMap);

            if (distances.empty()) continue;

#pragma omp atomic
            totalCalculations++;

            // 查找从sourceNode到其他边界节点的最短路径
            for (int j = i + 1; j < static_cast<int>(boundaryNodesVec.size()); j++) {
                long long targetNode = boundaryNodesVec[j];

                auto tit = nodeIndexMap.find(targetNode);
                if (tit == nodeIndexMap.end()) continue;

                int targetIdx = tit->second;

                if (targetIdx >= static_cast<int>(distances.size())) continue;

                double shortestPath = distances[targetIdx];

                // 只添加有效的路径（距离小于INF）
                if (shortestPath < INF) {
                    long long smaller = min(sourceNode, targetNode);
                    long long larger = max(sourceNode, targetNode);
                    pair<long long, long long> edgeKey = { smaller, larger };

                    lock_guard<mutex> lock(addedEdgesMtx);
                    if (addedEdges.insert(edgeKey).second) {
#pragma omp atomic
                        totalIntraPartitionEdges++;

                        lock_guard<mutex> outputLock(outputMtx);
                        outFile << smaller << " " << larger << " " << shortestPath << endl;
                    }
                }
            }
        }
    }

    outFile << "\n======================================================" << endl;
    outFile << "覆盖图统计:" << endl;
    outFile << "------------------------------------------------------" << endl;
    outFile << "原始边界边数量: " << totalBoundaryEdges << endl;
    outFile << "新增分区内边界节点连接边数量: " << totalIntraPartitionEdges << endl;
    outFile << "覆盖图总边数: " << (totalBoundaryEdges + totalIntraPartitionEdges) << endl;
    outFile << "分区内Dijkstra计算次数: " << totalCalculations << endl;
    outFile << "======================================================" << endl;

    outFile.close();

    auto endTime = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::seconds>(endTime - startTime);

    cout << "✓ 覆盖图构建完成，耗时: " << duration.count() << " 秒" << endl;
    cout << "✓ 覆盖图已保存到: " << outputFilename << endl;
}

// 生成详细报告
void writeDetailedOutput(const vector<PartitionInfo>& partitions,
    const string& outputFilename) {
    ofstream outFile(outputFilename);

    if (!outFile.is_open()) {
        cerr << "错误：无法创建输出文件: " << outputFilename << endl;
        return;
    }

    outFile << fixed << setprecision(6);

    int totalComponents = 0;
    int totalInternalEdges = 0;
    int totalBoundaryEdges = 0;
    int totalNodes = 0;
    int totalBoundaryNodes = 0;

    outFile << "==========================================================" << endl;
    outFile << "分区图分析报告" << endl;
    outFile << "==========================================================" << endl;

    for (int p = 0; p < static_cast<int>(partitions.size()); p++) {
        const auto& partition = partitions[p];

        outFile << "\n分区 " << p << ":" << endl;
        outFile << "----------------------------------------------------------" << endl;
        outFile << "节点数量: " << partition.nodes.size() << endl;
        outFile << "边界节点数量: " << partition.boundaryNodes.size() << endl;
        outFile << "内部边数量: " << partition.internalEdges.size() << endl;
        outFile << "边界边数量: " << partition.boundaryEdges.size() << endl;
        outFile << "连通分量数量: " << partition.connectedComponents << endl;

        totalComponents += partition.connectedComponents;
        totalInternalEdges += static_cast<int>(partition.internalEdges.size());
        totalBoundaryEdges += static_cast<int>(partition.boundaryEdges.size());
        totalNodes += static_cast<int>(partition.nodes.size());
        totalBoundaryNodes += static_cast<int>(partition.boundaryNodes.size());
    }

    outFile << "\n==========================================================" << endl;
    outFile << "统计汇总:" << endl;
    outFile << "----------------------------------------------------------" << endl;
    outFile << "总分区数: " << partitions.size() << endl;
    outFile << "总节点数: " << totalNodes << endl;
    outFile << "总边界节点数: " << totalBoundaryNodes << endl;
    outFile << "总内部边数: " << totalInternalEdges << endl;
    outFile << "总边界边数: " << totalBoundaryEdges << endl;
    outFile << "总连通分量数: " << totalComponents << endl;
    outFile << "平均连通分量数: " << (partitions.size() > 0 ? static_cast<double>(totalComponents) / partitions.size() : 0) << endl;
    outFile << "==========================================================" << endl;

    outFile.close();
}

int main(int argc, char* argv[]) {
    // 设置OpenMP线程数
    int num_threads = 10;
    omp_set_num_threads(num_threads);

    cout << "========================================" << endl;
    cout << "并行分区图分析工具 v5.0 (分区内Dijkstra优化版)" << endl;
    cout << "========================================" << endl;
    cout << "设置线程数: " << num_threads << endl;
    cout << "CPU核心数: " << thread::hardware_concurrency() << endl;
    cout << "实际使用的最大线程数: " << omp_get_max_threads() << endl;
    cout << "========================================" << endl;

    if (argc != 4) {
        cout << "使用方法: " << argv[0] << " <原始图文件.gr> <分区节点文件.txt> <输出文件前缀>" << endl;
        cout << "示例: " << argv[0] << " original_graph.gr partitioned_nodes.txt result" << endl;
        return 1;
    }

    string originalGraphFile = argv[1];
    string partitionFile = argv[2];
    string outputPrefix = argv[3];

    string detailedOutputFile = outputPrefix + "_detailed.txt";
    string edgesOutputFile = outputPrefix + "_edges.txt";
    string overgraphFile = outputPrefix + "_overgraph.txt";

    Timer timer;
    timer.start();

    // 1. 读取原始图
    cout << "[1/5] 读取原始图文件..." << endl;
    Graph originalGraph = Graph::createFromFileParallel(originalGraphFile);

    // 2. 读取分区节点
    cout << "[2/5] 读取分区文件..." << endl;
    auto partitions = readPartitionedNodes(partitionFile);

    if (partitions.empty()) {
        cerr << "错误：分区为空或读取失败" << endl;
        return 1;
    }

    // 3. 并行分离内部边和边界边
    cout << "[3/5] 并行分离内部边和边界边..." << endl;
    separateEdgesParallel(partitions, originalGraph);

    // 4. 并行计算连通分量
    cout << "[4/5] 并行计算连通分量..." << endl;
    calculateAllComponentsParallel(partitions);

    // 5. 构建覆盖图（使用优化版本）
    cout << "[5/5] 构建覆盖图（优化版）..." << endl;
    buildCoverGraphOptimized(partitions, originalGraph, overgraphFile);

    // 6. 写入文件
    cout << "生成输出文件..." << endl;
    writeDetailedOutput(partitions, detailedOutputFile);

    // 生成内部边文件
    ofstream edgesFile(edgesOutputFile);
    if (edgesFile.is_open()) {
        edgesFile << fixed << setprecision(6);
        for (int p = 0; p < static_cast<int>(partitions.size()); p++) {
            edgesFile << "分区 " << p << ":" << endl;
            for (const auto& edge : partitions[p].internalEdges) {
                edgesFile << edge.src << "   " << edge.dst << "   " << edge.weight << endl;
            }
            edgesFile << endl;
        }
        edgesFile.close();
        cout << "✓ 内部边列表已保存到: " << edgesOutputFile << endl;
    }

    cout << "========================================" << endl;
    cout << "并行分析完成！" << endl;
    timer.end("Overlay graph");
    cout << "✓ 详细报告已保存到: " << detailedOutputFile << endl;
    cout << "✓ 覆盖图已保存到: " << overgraphFile << endl;
    cout << "========================================" << endl;

    return 0;
}