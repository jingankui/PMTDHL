#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <chrono>
#include <random>
#include <string>
#include <sstream>
#include <cstdint>
#include <windows.h>
#include <limits>
#include <omp.h>
#include <mutex>
#include <tuple>

using NodeId = uint32_t;
using Distance = uint64_t;
using Index = size_t;
constexpr size_t QUERY_COUNT = 500; // 筛选节点数>500的分区
using TimePoint = std::chrono::high_resolution_clock::time_point;

enum class GraphType : uint8_t {
    DIRECTED,
    UNDIRECTED
};

struct DirectedNode {
    std::vector<NodeId> A;
    std::vector<Distance> DOUT;
    std::vector<Distance> DIN;
    std::vector<Index> P;
    std::vector<NodeId> Acce;
};

struct UndirectedNode {
    std::vector<NodeId> A;
    std::vector<Distance> D;
    std::vector<Index> P;
    std::vector<NodeId> Acce;
};

// ===================== 【新增】原始图/分区原始邻接 数据结构 =====================
struct OriginalGraph {
    uint32_t node_count = 0;   // 原始图总节点数
    uint32_t edge_count = 0;   // 原始图总边数
    // 高效存储原始边：无向图存 u<v 键，O(1) 判断是否为原始邻接
    std::unordered_set<size_t> original_edges;
    // 全局原始邻接表 (节点 -> 原始邻居集合)
    std::unordered_map<NodeId, std::unordered_set<NodeId>> adj;

    // 生成唯一键：u<v 保证无向边去重
    size_t get_edge_key(NodeId u, NodeId v) const {
        if (u > v) std::swap(u, v);
        return (size_t)u << 32 | v;
    }
};

struct Graph {
    GraphType type;
    uint32_t vertex_count = 0;
    uint32_t edge_count = 0;
    uint32_t tree_width = 0;
    uint32_t node_count = 0;

    std::unordered_map<std::string, std::vector<NodeId>> partitions;
    std::unordered_map<NodeId, std::string> node_to_partition;
    std::unordered_set<NodeId> cover_graph_nodes;

    // 预计算：分区与覆盖图的交集（边界节点）
    std::unordered_map<std::string, std::vector<NodeId>> partition_cover_intersection;

    std::unordered_map<std::string, std::unordered_map<NodeId, DirectedNode>> dir_partition_indexes;
    std::unordered_map<std::string, std::unordered_map<NodeId, UndirectedNode>> undir_partition_indexes;
    std::unordered_map<NodeId, DirectedNode> dir_cover_index;
    std::unordered_map<NodeId, UndirectedNode> undir_cover_index;

    // ===================== 【新增】核心成员 =====================
    OriginalGraph original; // 原始图数据
    // 筛选后：节点数>500的分区 → 【纯原始邻接表】(排除捷径，边界节点含覆盖图邻接)
    std::unordered_map<std::string, std::unordered_map<NodeId, std::unordered_set<NodeId>>> partition_original_adj;
    // 分区原始邻接矩阵（可选，邻接表转矩阵）
    std::unordered_map<std::string, std::vector<std::vector<bool>>> partition_original_matrix;
};

static inline std::vector<std::string> split(const std::string& s, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(s);
    while (std::getline(tokenStream, token, delimiter)) {
        if (!token.empty())
            tokens.push_back(token);
    }
    return tokens;
}

static inline NodeId find_rightmost_lca(const std::vector<NodeId>& a1, const std::vector<NodeId>& a2) {
    if (a1.empty() || a2.empty()) return 0;
    std::unordered_set<NodeId> set(a2.begin(), a2.end());
    for (auto it = a1.rbegin(); it != a1.rend(); ++it) {
        if (set.count(*it)) return *it;
    }
    return 0;
}
static inline double elapsed_sec(TimePoint start, TimePoint end) {
    return std::chrono::duration<double>(end - start).count();
}

using TimePoint = std::chrono::high_resolution_clock::time_point;
static inline TimePoint now() {
    return std::chrono::high_resolution_clock::now();
}
static inline double elapsed_ms(TimePoint start, TimePoint end) {
    return std::chrono::duration<double, std::milli>(end - start).count();
}

// ===================== 【新增核心函数1】加载原始图txt文件 =====================
// 读取格式：第一行 节点数 边数 | 后续行 起点 终点 权重
bool load_original_graph(Graph& g, const std::string& original_file_path) {
    std::ifstream file(original_file_path);
    if (!file.is_open()) {
        std::cerr << "错误：无法打开原始图文件！路径:" << original_file_path << std::endl;
        return false;
    }

    OriginalGraph& og = g.original;
    std::string line;

    // 第一行：节点数 边数
    if (std::getline(file, line)) {
        std::vector<std::string> parts = split(line, ' ');
        if (parts.size() >= 2) {
            og.node_count = std::stoul(parts[0]);
            og.edge_count = std::stoul(parts[1]);
        }
    }

    // 读取所有边
    while (std::getline(file, line)) {
        if (line.empty()) continue;
        std::vector<std::string> parts = split(line, ' ');
        if (parts.size() < 3) continue;

        NodeId u = std::stoul(parts[0]);
        NodeId v = std::stoul(parts[1]);
        // 忽略权重，只存储邻接关系

        // 添加到原始边集合
        size_t key = og.get_edge_key(u, v);
        og.original_edges.insert(key);
        // 添加到全局邻接表
        og.adj[u].insert(v);
        og.adj[v].insert(u);
    }

    file.close();
    std::cout << "原始图加载完成！节点数:" << og.node_count << " 边数:" << og.edge_count << std::endl;
    return true;
}

// ===================== 【新增核心函数2】筛选大分区+构建纯原始邻接表/矩阵 =====================
// 功能：1. 筛选节点数>500的分区 2. 构建原始邻接（排除捷径）3. 边界节点叠加覆盖图邻接
void build_original_adj_for_large_partitions(Graph& g) {
    if (g.original.adj.empty()) {
        std::cerr << "错误：请先加载原始图!" << std::endl;
        return;
    }

    const OriginalGraph& og = g.original;
    g.partition_original_adj.clear();
    g.partition_original_matrix.clear();

    // 步骤1：筛选 节点数>QUERY_COUNT(500) 的分区
    std::vector<std::string> large_partitions;
    for (const auto& kv : g.partitions) {
        const std::string& part_name = kv.first;
        const auto& nodes = kv.second;
        if (nodes.size() > QUERY_COUNT) {
            large_partitions.push_back(part_name);
        }
    }

    if (large_partitions.empty()) {
        std::cout << "未找到节点数>" << QUERY_COUNT << "的大分区!" << std::endl;
        return;
    }
    std::cout << "\n找到大分区总数:" << large_partitions.size() << std::endl;

    // 步骤2：为每个大分区构建【纯原始邻接表】
    for (const std::string& part_name : large_partitions) {
        const auto& part_nodes = g.partitions.at(part_name);
        const auto& border_nodes = g.partition_cover_intersection.at(part_name); // 边界节点
        std::unordered_map<NodeId, std::unordered_set<NodeId>> part_original_adj;

        // 遍历分区内所有节点，构建原始邻接
        for (NodeId u : part_nodes) {
            // 初始化空邻接集合
            part_original_adj[u];

            // 规则1：普通节点 → 只取原始图邻接（排除捷径）
            if (og.adj.count(u)) {
                for (NodeId v : og.adj.at(u)) {
                    // 仅保留分区内的原始邻居
                    if (g.node_to_partition.count(v) && g.node_to_partition.at(v) == part_name) {
                        part_original_adj[u].insert(v);
                    }
                }
            }

            // 规则2：边界节点（分区+覆盖图交集）→ 额外添加覆盖图内的原始邻接
            if (std::find(border_nodes.begin(), border_nodes.end(), u) != border_nodes.end()) {
                for (NodeId v : g.cover_graph_nodes) {
                    // 判断是否为原始邻接 + 不是自己
                    if (u != v && og.original_edges.count(og.get_edge_key(u, v))) {
                        part_original_adj[u].insert(v);
                    }
                }
            }
        }

        // 保存分区原始邻接表
        g.partition_original_adj[part_name] = part_original_adj;

        // 步骤3（可选）：邻接表转 邻接矩阵（true=原始邻接，false=无/捷径）
        std::unordered_map<NodeId, size_t> node2idx;
        for (size_t i = 0; i < part_nodes.size(); ++i) {
            node2idx[part_nodes[i]] = i;
        }
        std::vector<std::vector<bool>> matrix(part_nodes.size(), std::vector<bool>(part_nodes.size(), false));
        for (NodeId u : part_nodes) {
            size_t i = node2idx[u];
            for (NodeId v : part_original_adj[u]) {
                size_t j = node2idx[v];
                matrix[i][j] = true;
            }
        }
        g.partition_original_matrix[part_name] = matrix;

        // 输出验证
        std::cout << "分区 " << part_name << " 构建完成｜节点数:" << part_nodes.size()
            << "｜原始邻接表构建完成" << std::endl;
    }
}

// ===================== 【新增】工具函数：判断两个节点是否为【原始邻接】 =====================
bool is_original_neighbor(const Graph& g, NodeId u, NodeId v) {
    if (g.original.adj.empty()) return false;
    return g.original.original_edges.count(g.original.get_edge_key(u, v)) > 0;
}

// ========================================================================================
// 你原有代码（无任何修改）
// ========================================================================================
bool parse_index_file(const std::string& file_path, Graph& graph) {
    std::ifstream file(file_path);
    if (!file.is_open()) {
        std::cerr << "Error: Failed to open index file! Path: " << file_path << std::endl;
        return false;
    }

    std::string line;
    bool in_node_data = false;
    NodeId current_node = 0;
    bool in_overlay = false;
    std::string current_partition;

    while (std::getline(file, line)) {
        if (line.empty()) continue;

        if (line.substr(0, 3) == "===") {
            if (line.find("Overlay") != std::string::npos) {
                in_overlay = true;
            }
            else {
                in_overlay = false;
                std::vector<std::string> parts = split(line, ' ');
                if (parts.size() < 2) continue;
                current_partition = parts[1];
                graph.partitions[current_partition];
            }
            continue;
        }

        if (!in_overlay) {
            if (line.find("VertexCount:") != std::string::npos)
                graph.vertex_count = std::stoul(split(line, ':')[1]);
            else if (line.find("EdgeCount:") != std::string::npos)
                graph.edge_count = std::stoul(split(line, ':')[1]);
            else if (line.find("TreeWidth:") != std::string::npos)
                graph.tree_width = std::stoul(split(line, ':')[1]);
            else if (line.find("NodeCount:") != std::string::npos)
                graph.node_count = std::stoul(split(line, ':')[1]);
            else if (line.find("GraphType: DIRECTED") != std::string::npos)
                graph.type = GraphType::DIRECTED;
            else if (line.find("GraphType: UNDIRECTED") != std::string::npos)
                graph.type = GraphType::UNDIRECTED;
        }

        if (line == "[NODE_DATA]") {
            in_node_data = true;
            continue;
        }

        if (in_node_data) {
            if (line.substr(0, 4) == "NODE") {
                std::vector<std::string> node_parts = split(line, ' ');
                if (node_parts.size() < 2) continue;
                current_node = std::stoul(node_parts[1]);
                if (!in_overlay) {
                    graph.partitions[current_partition].push_back(current_node);
                    graph.node_to_partition[current_node] = current_partition;
                }
                else {
                    graph.cover_graph_nodes.insert(current_node);
                }
                continue;
            }

            if (in_overlay) {
                if (graph.type == GraphType::DIRECTED) {
                    auto& node = graph.dir_cover_index[current_node];
                    if (line.find("A:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.A.push_back(std::stoul(s));
                    else if (line.find("DOUT:") != std::string::npos)
                        for (const auto& s : split(line.substr(5), ' ')) node.DOUT.push_back(std::stoull(s));
                    else if (line.find("DIN:") != std::string::npos)
                        for (const auto& s : split(line.substr(4), ' ')) node.DIN.push_back(std::stoull(s));
                    else if (line.find("P:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.P.push_back(std::stoul(s));
                    else if (line.find("Acce:") != std::string::npos)
                        for (const auto& s : split(line.substr(5), ' ')) node.Acce.push_back(std::stoul(s));
                }
                else {
                    auto& node = graph.undir_cover_index[current_node];
                    if (line.find("A:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.A.push_back(std::stoul(s));
                    else if (line.find("D:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.D.push_back(std::stoull(s));
                    else if (line.find("P:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.P.push_back(std::stoul(s));
                    else if (line.find("Acce:") != std::string::npos)
                        for (const auto& s : split(line.substr(5), ' ')) node.Acce.push_back(std::stoul(s));
                }
            }
            else {
                if (graph.type == GraphType::DIRECTED) {
                    auto& part_index = graph.dir_partition_indexes[current_partition];
                    auto& node = part_index[current_node];
                    if (line.find("A:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.A.push_back(std::stoul(s));
                    else if (line.find("DOUT:") != std::string::npos)
                        for (const auto& s : split(line.substr(5), ' ')) node.DOUT.push_back(std::stoull(s));
                    else if (line.find("DIN:") != std::string::npos)
                        for (const auto& s : split(line.substr(4), ' ')) node.DIN.push_back(std::stoull(s));
                    else if (line.find("P:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.P.push_back(std::stoul(s));
                    else if (line.find("Acce:") != std::string::npos)
                        for (const auto& s : split(line.substr(5), ' ')) node.Acce.push_back(std::stoul(s));
                }
                else {
                    auto& part_index = graph.undir_partition_indexes[current_partition];
                    auto& node = part_index[current_node];
                    if (line.find("A:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.A.push_back(std::stoul(s));
                    else if (line.find("D:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.D.push_back(std::stoull(s));
                    else if (line.find("P:") != std::string::npos)
                        for (const auto& s : split(line.substr(2), ' ')) node.P.push_back(std::stoul(s));
                    else if (line.find("Acce:") != std::string::npos)
                        for (const auto& s : split(line.substr(5), ' ')) node.Acce.push_back(std::stoul(s));
                }
            }
        }
    }

    if (graph.type == GraphType::UNDIRECTED) {
        for (const auto& kv : graph.partitions) {
            const std::string& part_name = kv.first;
            const std::vector<NodeId>& part_nodes = kv.second;
            std::vector<NodeId> intersection;

            for (NodeId n : part_nodes) {
                if (graph.cover_graph_nodes.count(n)) {
                    intersection.push_back(n);
                }
            }
            graph.partition_cover_intersection[part_name] = intersection;
        }
    }

    std::vector<std::string> empty_parts;
    for (auto& kv : graph.partitions) {
        if (kv.second.empty()) empty_parts.push_back(kv.first);
    }
    for (auto& p : empty_parts) graph.partitions.erase(p);

    file.close();
    std::cout << "Parsing completed! Overlay graph node count: " << graph.cover_graph_nodes.size()
        << " | Valid partition count: " << graph.partitions.size() << std::endl;
    return true;
}

Distance query_directed(const Graph& g, NodeId va, NodeId vb) {
    std::string part_a, part_b;
    bool a_in_part = (g.node_to_partition.find(va) != g.node_to_partition.end());
    bool b_in_part = (g.node_to_partition.find(vb) != g.node_to_partition.end());

    if (a_in_part) part_a = g.node_to_partition.at(va);
    if (b_in_part) part_b = g.node_to_partition.at(vb);

    const DirectedNode* node_a = nullptr, * node_b = nullptr;

    if (a_in_part) {
        auto it = g.dir_partition_indexes.find(part_a);
        if (it != g.dir_partition_indexes.end()) {
            auto j = it->second.find(va);
            if (j != it->second.end()) node_a = &j->second;
        }
    }
    else {
        auto it = g.dir_cover_index.find(va);
        if (it != g.dir_cover_index.end()) node_a = &it->second;
    }

    if (b_in_part) {
        auto it = g.dir_partition_indexes.find(part_b);
        if (it != g.dir_partition_indexes.end()) {
            auto j = it->second.find(vb);
            if (j != it->second.end()) node_b = &j->second;
        }
    }
    else {
        auto it = g.dir_cover_index.find(vb);
        if (it != g.dir_cover_index.end()) node_b = &it->second;
    }

    if (!node_a || !node_b) return UINT64_MAX;

    bool a_deeper = node_a->A.size() > node_b->A.size();
    const DirectedNode* desc = a_deeper ? node_a : node_b;
    NodeId desc_id = a_deeper ? va : vb;
    NodeId anc_id = a_deeper ? vb : va;

    auto pos = std::find(desc->A.begin(), desc->A.end(), anc_id);
    if (pos != desc->A.end()) {
        Index idx = pos - desc->A.begin();
        if (desc_id == va && anc_id == vb)
            return idx < desc->DOUT.size() ? desc->DOUT[idx] : UINT64_MAX;
        else
            return idx < desc->DIN.size() ? desc->DIN[idx] : UINT64_MAX;
    }

    NodeId lca = find_rightmost_lca(node_a->A, node_b->A);
    if (lca == 0) return UINT64_MAX;

    const DirectedNode* lca_node = nullptr;
    auto it = g.node_to_partition.find(lca);
    if (it != g.node_to_partition.end()) {
        auto pit = g.dir_partition_indexes.find(it->second);
        if (pit != g.dir_partition_indexes.end()) {
            auto nit = pit->second.find(lca);
            if (nit != pit->second.end()) lca_node = &nit->second;
        }
    }
    else {
        auto cit = g.dir_cover_index.find(lca);
        if (cit != g.dir_cover_index.end()) lca_node = &cit->second;
    }

    if (!lca_node || lca_node->P.empty()) return UINT64_MAX;

    Distance min_d = UINT64_MAX;
    for (Index p : lca_node->P) {
        if (p >= node_a->DOUT.size() || p >= node_b->DIN.size()) continue;
        Distance candidate = node_a->DOUT[p] + node_b->DIN[p];
        if (candidate < min_d) {
            min_d = candidate;
        }
    }
    return min_d;
}

Distance query_undirected_partition(const Graph& g, const std::string& p, NodeId a, NodeId b) {
    auto it = g.undir_partition_indexes.find(p);
    if (it == g.undir_partition_indexes.end()) return UINT64_MAX;
    auto ia = it->second.find(a), ib = it->second.find(b);
    if (ia == it->second.end() || ib == it->second.end()) return UINT64_MAX;

    const auto& na = ia->second, nb = ib->second;
    bool a_deeper = na.A.size() > nb.A.size();
    const auto& deep = a_deeper ? na : nb;
    NodeId target = a_deeper ? b : a;

    auto pos = std::find(deep.A.begin(), deep.A.end(), target);
    if (pos != deep.A.end()) {
        Index idx = pos - deep.A.begin();
        return idx < deep.D.size() ? deep.D[idx] : UINT64_MAX;
    }

    NodeId lca = find_rightmost_lca(na.A, nb.A);
    if (lca == 0) return UINT64_MAX;
    auto il = it->second.find(lca);
    if (il == it->second.end() || il->second.P.empty()) return UINT64_MAX;

    Distance min_d = UINT64_MAX;
    for (Index pidx : il->second.P) {
        if (pidx >= na.D.size() || pidx >= nb.D.size()) continue;
        Distance candidate = na.D[pidx] + nb.D[pidx];
        if (candidate < min_d) {
            min_d = candidate;
        }
    }
    return min_d;
}

Distance query_undirected_cover(const Graph& g, NodeId a, NodeId b) {
    auto ia = g.undir_cover_index.find(a), ib = g.undir_cover_index.find(b);
    if (ia == g.undir_cover_index.end() || ib == g.undir_cover_index.end()) return UINT64_MAX;

    const auto& na = ia->second, nb = ib->second;
    bool a_deeper = na.A.size() > nb.A.size();
    const auto& deep = a_deeper ? na : nb;
    NodeId target = a_deeper ? b : a;

    auto pos = std::find(deep.A.begin(), deep.A.end(), target);
    if (pos != deep.A.end()) {
        Index idx = pos - deep.A.begin();
        return idx < deep.D.size() ? deep.D[idx] : UINT64_MAX;
    }

    NodeId lca = find_rightmost_lca(na.A, nb.A);
    if (lca == 0) return UINT64_MAX;
    auto il = g.undir_cover_index.find(lca);
    if (il == g.undir_cover_index.end() || il->second.P.empty()) return UINT64_MAX;

    Distance min_d = UINT64_MAX;
    for (Index pidx : il->second.P) {
        if (pidx >= na.D.size() || pidx >= nb.D.size()) continue;
        Distance candidate = na.D[pidx] + nb.D[pidx];
        if (candidate < min_d) {
            min_d = candidate;
        }
    }
    return min_d;
}

Distance query_best_undirected_same_part(const Graph& g, const std::string& part, NodeId c1, NodeId c2) {
    Distance d_part = query_undirected_partition(g, part, c1, c2);
    Distance d_cov = query_undirected_cover(g, c1, c2);
    Distance res = UINT64_MAX;

    if (d_part != UINT64_MAX) {
        res = d_part;
    }
    if (d_cov != UINT64_MAX) {
        if (res == UINT64_MAX || d_cov < res) {
            res = d_cov;
        }
    }
    return res;
}

Distance query_undir_local_3stage(const Graph& g, const std::string& part, NodeId a, NodeId b, const std::vector<NodeId>& C) {
    Distance min_total = UINT64_MAX;
    for (NodeId c1 : C) {
        Distance d1 = query_undirected_partition(g, part, a, c1);
        if (d1 == UINT64_MAX) continue;
        for (NodeId c2 : C) {
            Distance d2 = query_best_undirected_same_part(g, part, c1, c2);
            if (d2 == UINT64_MAX) continue;
            for (NodeId c3 : C) {
                Distance d3 = query_undirected_partition(g, part, c3, b);
                if (d3 == UINT64_MAX) continue;

                Distance total = d1 + d2 + d3;
                if (min_total == UINT64_MAX || total < min_total) {
                    min_total = total;
                }
            }
        }
    }
    return min_total;
}

Distance query_undir_cross_3stage(const Graph& g, const std::string& p1, const std::string& p2, NodeId a, NodeId b,
    const std::vector<NodeId>& C1, const std::vector<NodeId>& C2) {
    Distance min_total = UINT64_MAX;
    for (NodeId c1 : C1) {
        Distance d1 = query_undirected_partition(g, p1, a, c1);
        if (d1 == UINT64_MAX) continue;
        for (NodeId c2 : C2) {
            Distance d2 = query_undirected_cover(g, c1, c2);
            if (d2 == UINT64_MAX) continue;
            for (NodeId c3 : C2) {
                Distance d3 = query_undirected_partition(g, p2, c3, b);
                if (d3 == UINT64_MAX) continue;

                Distance total = d1 + d2 + d3;
                if (min_total == UINT64_MAX || total < min_total) {
                    min_total = total;
                }
            }
        }
    }
    return min_total;
}

Distance query_undirected_local(const Graph& g, NodeId va, NodeId vb) {
    std::string part;
    try { part = g.node_to_partition.at(va); }
    catch (...) { return UINT64_MAX; }
    Distance local = query_undirected_partition(g, part, va, vb);

    const auto& C = g.partition_cover_intersection.at(part);
    if (C.empty()) return local;

    Distance three = query_undir_local_3stage(g, part, va, vb, C);
    Distance res = local;

    if (three != UINT64_MAX) {
        if (res == UINT64_MAX || three < res) {
            res = three;
        }
    }
    return res;
}

Distance query_undirected_cross(const Graph& g, NodeId va, NodeId vb) {
    if (g.cover_graph_nodes.empty()) return query_undirected_local(g, va, vb);
    std::string p1, p2;
    try {
        p1 = g.node_to_partition.at(va);
        p2 = g.node_to_partition.at(vb);
    }
    catch (...) { return UINT64_MAX; }

    const auto& C1 = g.partition_cover_intersection.at(p1);
    const auto& C2 = g.partition_cover_intersection.at(p2);

    if (C1.empty() || C2.empty()) return query_undirected_local(g, va, vb);
    return query_undir_cross_3stage(g, p1, p2, va, vb, C1, C2);
}

void save_pairs_to_file(const std::vector<std::pair<NodeId, NodeId>>& pairs, const std::string& filename) {
    std::ofstream f(filename);
    for (auto& p : pairs) f << p.first << " " << p.second << "\n";
}

std::vector<std::pair<NodeId, NodeId>> load_pairs_from_file(const std::string& filename) {
    std::vector<std::pair<NodeId, NodeId>> pairs;
    std::ifstream f(filename);
    NodeId u, v;
    while (f >> u >> v) pairs.emplace_back(u, v);
    return pairs;
}

static std::mutex rng_mtx;
static std::mt19937 rng(std::random_device{}());

std::vector<std::pair<NodeId, NodeId>> generate_local_pairs(Graph& g) {
    std::vector<std::string> valid_parts;
    for (auto& kv : g.partitions) {
        if (kv.second.size() >= QUERY_COUNT)
            valid_parts.push_back(kv.first);
    }
    if (valid_parts.empty()) return {};

    std::string part;
    { std::lock_guard<std::mutex> l(rng_mtx); part = valid_parts[std::uniform_int_distribution<>(0, valid_parts.size() - 1)(rng)]; }
    auto& nodes = g.partitions[part];
    std::vector<std::pair<NodeId, NodeId>> res;
    res.reserve(QUERY_COUNT);

    std::lock_guard<std::mutex> l(rng_mtx);
    std::uniform_int_distribution<> d(0, nodes.size() - 1);
    for (size_t i = 0; i < QUERY_COUNT; i++) res.emplace_back(nodes[d(rng)], nodes[d(rng)]);

    save_pairs_to_file(res, "local_pairs.txt");
    return res;
}

std::vector<std::pair<NodeId, NodeId>> generate_cross_pairs(Graph& g) {
    std::vector<std::string> valid_parts;
    for (auto& kv : g.partitions) {
        if (kv.second.size() >= QUERY_COUNT)
            valid_parts.push_back(kv.first);
    }
    if (valid_parts.size() < 2) return {};

    std::vector<std::pair<NodeId, NodeId>> res;
    res.reserve(QUERY_COUNT);
    std::lock_guard<std::mutex> l(rng_mtx);

    for (size_t i = 0; i < QUERY_COUNT; i++) {
        std::uniform_int_distribution<> pd(0, valid_parts.size() - 1);
        int x = pd(rng), y; do { y = pd(rng); } while (x == y);
        auto& n1 = g.partitions[valid_parts[x]];
        auto& n2 = g.partitions[valid_parts[y]];
        std::uniform_int_distribution<> d1(0, n1.size() - 1), d2(0, n2.size() - 1);
        res.emplace_back(n1[d1(rng)], n2[d2(rng)]);
    }

    save_pairs_to_file(res, "cross_pairs.txt");
    return res;
}

void run_parallel_queries(Graph& g, size_t thread_num) {
    omp_set_num_threads((int)thread_num);
    if (g.type == GraphType::DIRECTED) {
        std::vector<NodeId> all;
        for (auto& kv : g.partitions) for (NodeId n : kv.second) all.push_back(n);
        for (NodeId n : g.cover_graph_nodes) all.push_back(n);
        if (all.empty()) return;
        std::vector<std::pair<NodeId, NodeId>> pairs;
        {
            std::lock_guard<std::mutex> l(rng_mtx);
            std::uniform_int_distribution<> d(0, all.size() - 1);
            for (size_t i = 0; i < QUERY_COUNT; ++i) pairs.emplace_back(all[d(rng)], all[d(rng)]);
        }
        auto st = now();
        std::vector<Distance> res(QUERY_COUNT);
#pragma omp parallel for
        for (int i = 0; i < (int)QUERY_COUNT; ++i) res[i] = query_directed(g, pairs[i].first, pairs[i].second);
        auto ed = now();
        std::cout << "\nDirected total: " << elapsed_ms(st, ed) << "ms\n";
    }
    else {
        auto local_pairs = generate_local_pairs(g);
        auto st1 = now();
        std::vector<Distance> rl(QUERY_COUNT);
#pragma omp parallel for
        for (int i = 0; i < (int)QUERY_COUNT; ++i) rl[i] = query_undirected_local(g, local_pairs[i].first, local_pairs[i].second);
        auto ed1 = now();
        std::cout << "\nUndir local total: " << elapsed_ms(st1, ed1) << " ms | Average: " << elapsed_ms(st1, ed1) / QUERY_COUNT << " ms\n";

        auto cross_pairs = generate_cross_pairs(g);
        auto st2 = now();
        std::vector<Distance> rc(QUERY_COUNT);
#pragma omp parallel for
        for (int i = 0; i < (int)QUERY_COUNT; ++i) rc[i] = query_undirected_cross(g, cross_pairs[i].first, cross_pairs[i].second);
        auto ed2 = now();
        std::cout << "Undir cross total: " << elapsed_ms(st2, ed2) << " ms | Average: " << elapsed_ms(st2, ed2) / QUERY_COUNT << " ms\n";
    }
}

// ===================== 【修改main函数】集成新增功能 =====================
/*int main() {
    SetConsoleOutputCP(CP_UTF8);

    // 1. 配置文件路径（请修改为你的实际路径）
    std::string index_file_path = "./VCTDHL/NY/tdhl_index.txt"; // 索引文件
    std::string original_file_path = "./original_graph.txt";    // 原始图txt文件

    Graph graph;

    // 2. 解析索引文件（原有逻辑）
    auto st = now();
    std::cout << "开始解析索引文件..." << std::endl;
    if (!parse_index_file(index_file_path, graph)) return -1;
    auto tt = now();
    std::cout << "索引解析耗时：" << elapsed_ms(st, tt) << "ms" << std::endl;

    // 3. 【新增】加载原始图文件
    std::cout << "\n开始加载原始图..." << std::endl;
    if (!load_original_graph(graph, original_file_path)) return -1;

    // 4. 【新增】筛选大分区+构建纯原始邻接表/矩阵
    build_original_adj_for_large_partitions(graph);

    // 5. 原有查询逻辑（无修改）
    std::cout << "\n开始执行并行查询..." << std::endl;
    std::cout << "图类型：" << (graph.type == GraphType::DIRECTED ? "有向图" : "无向图") << std::endl;
    run_parallel_queries(graph, 4);

    // ===================== 【新增】使用示例：验证原始邻接 =====================
    std::cout << "\n===== 原始邻接校验示例 =====" << std::endl;
    if (!graph.partition_original_adj.empty()) {
        auto& part = graph.partition_original_adj.begin()->first;
        auto& adj = graph.partition_original_adj[part];
        NodeId u = adj.begin()->first;
        std::cout << "分区 " << part << " 中节点 " << u << " 的原始邻居：";
        for (NodeId v : adj[u]) std::cout << v << " ";
        std::cout << std::endl;
        std::cout << "节点 " << u << " 和 第一个邻居 是否为原始邻接："
            << (is_original_neighbor(graph, u, *adj[u].begin()) ? "是" : "否") << std::endl;
    }

    return 0;
}*/

#include <queue>
#include <iomanip>
#include <fstream>
#include <random>
#include <thread>
#include <vector>
#include <mutex>
#include <functional>

using ResultHeap = std::priority_queue<std::pair<Distance, NodeId>>;
using SearchQueue = std::priority_queue<std::pair<Distance, NodeId>,
    std::vector<std::pair<Distance, NodeId>>, std::greater<>>;

const int THREAD_COUNT = 8;

bool build_single_partition_adj(
    const Graph& g,
    const std::string& part_name,
    std::unordered_map<NodeId, std::unordered_set<NodeId>>& out_adj
) {
    out_adj.clear();
    const auto& part_nodes = g.partitions.at(part_name);
    const auto& border_nodes = g.partition_cover_intersection.at(part_name);
    const OriginalGraph& og = g.original;

    for (NodeId u : part_nodes) {
        out_adj[u];
        if (og.adj.count(u))
            for (NodeId v : og.adj.at(u))
                if (g.node_to_partition.count(v) && g.node_to_partition.at(v) == part_name)
                    out_adj[u].insert(v);

        if (std::find(border_nodes.begin(), border_nodes.end(), u) != border_nodes.end())
            for (NodeId v : g.cover_graph_nodes)
                if (u != v && og.original_edges.count(og.get_edge_key(u, v)))
                    out_adj[u].insert(v);
    }
    return true;
}

bool knn_query(
    const Graph& g,
    const std::unordered_map<NodeId, std::unordered_set<NodeId>>& adj,
    NodeId vs, int k,
    std::vector<std::pair<NodeId, Distance>>& knn_result)
{
    knn_result.clear();
    if (k <= 0 || !adj.count(vs)) return false;

    ResultHeap result_heap;
    std::unordered_set<NodeId> visited;
    SearchQueue pq;
    pq.emplace(0, vs);

    while (!pq.empty()) {
        auto [current_dist, u] = pq.top();
        pq.pop();

        if (result_heap.size() == k && current_dist > result_heap.top().first)
            break;

        if (visited.count(u)) continue;
        visited.insert(u);

        if (u != vs) {
            if (result_heap.size() < k)
                result_heap.emplace(current_dist, u);
            else if (current_dist < result_heap.top().first) {
                result_heap.pop();
                result_heap.emplace(current_dist, u);
            }
        }

        if (!adj.count(u)) continue;
        for (NodeId v : adj.at(u)) {
            if (visited.count(v)) continue;
            Distance d = query_undirected_local(g, vs, v);
            if (d == UINT64_MAX) continue;
            pq.emplace(d, v);
        }
    }

    while (!result_heap.empty()) {
        auto [d, v] = result_heap.top();
        result_heap.pop();
        knn_result.emplace_back(v, d);
    }
    std::reverse(knn_result.begin(), knn_result.end());
    return true;
}

void generate_nodes_from_single_partition(
    Graph& g,
    const std::vector<std::string>& valid_parts,
    int need_count,
    const std::string& filename)
{
    std::mt19937 rng(std::random_device{}());
    std::uniform_int_distribution<> part_dist(0, valid_parts.size() - 1);
    std::string selected_part = valid_parts[part_dist(rng)];
    const auto& nodes_in_part = g.partitions.at(selected_part);

    std::vector<std::pair<std::string, NodeId>> res;
    std::uniform_int_distribution<> node_dist(0, nodes_in_part.size() - 1);
    while (res.size() < need_count) {
        NodeId q = nodes_in_part[node_dist(rng)];
        res.emplace_back(selected_part, q);
    }

    std::ofstream f(filename);
    for (auto& [p, q] : res) f << p << " " << q << "\n";
    std::cout << "已生成 " << need_count << " 个节点，来自分区: " << selected_part << "\n";
}

std::vector<std::pair<std::string, NodeId>> load_query_nodes(const std::string& filename) {
    std::vector<std::pair<std::string, NodeId>> res;
    std::ifstream f(filename);
    std::string part;
    NodeId q;
    while (f >> part >> q) res.emplace_back(part, q);
    return res;
}

void run_knn_experiment(Graph& g) {
    std::vector<int> COUNTS = { 50, 60, 70, 80, 90 };
    std::vector<int> Ks = { 3, 5};

    std::vector<std::string> parts;
    for (auto& p : g.partitions)
        if (p.second.size() > QUERY_COUNT)
            parts.push_back(p.first);

    std::cout << "提前构建分区邻接表...\n";
    std::unordered_map<std::string, std::unordered_map<NodeId, std::unordered_set<NodeId>>> part_adjs;
    for (auto& name : parts)
        build_single_partition_adj(g, name, part_adjs[name]);

    std::cout << "生成固定查询节点...\n";
    for (int c : COUNTS)
        generate_nodes_from_single_partition(g, parts, c, "query_nodes_" + std::to_string(c) + ".txt");

    std::cout << "\n======== 旧索引 8线程并行 KNN ========\n";
    for (int cnt : COUNTS) {
        auto nodes = load_query_nodes("query_nodes_" + std::to_string(cnt) + ".txt");
        std::cout << "\n>>> " << cnt << " 个节点（8线程）\n";

        for (int k : Ks) {
            auto st = now();
            int total_ok = 0;
            std::mutex mtx;

            auto worker = [&](int start, int end) {
                int local_ok = 0;
                for (int i = start; i < end; ++i) {
                    auto& [part, q] = nodes[i];
                    std::vector<std::pair<NodeId, Distance>> tmp;
                    if (knn_query(g, part_adjs[part], q, k, tmp))
                    {
                        local_ok++;
                        std::lock_guard<std::mutex> lock(mtx);
                        std::cout << "已经完成 " << q << " 的 " << k << "NN 计算\n";
                    }
                }
                std::lock_guard<std::mutex> lock(mtx);
                total_ok += local_ok;
                };

            int total = nodes.size();
            int per = total / THREAD_COUNT;
            std::vector<std::thread> threads;
            for (int t = 0; t < THREAD_COUNT; ++t) {
                int s = t * per;
                int e = (t == THREAD_COUNT - 1) ? total : (t + 1) * per;
                threads.emplace_back(worker, s, e);
            }
            for (auto& th : threads) th.join();

            double cost = elapsed_sec(st, now());
            std::cout << k << "NN: " << cost << " s\n";
        }
    }
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    std::string index_path = "./VCTDHL/COL/tdhl_index.txt";
    std::string graph_path = "./COL.txt";

    Graph g;
    auto st1 = now();
    std::cout << "Begin parsing the index file" << std::endl;
    if (!parse_index_file(index_path, g)) return -1;
    auto ed1 = now();
    std::cout << "索引解析总耗时: " << elapsed_ms(st1, ed1) << "ms " << std::endl;
    std::cout << "图类型: " << (g.type == GraphType::DIRECTED ? "DIRECTED Graph" : "UnDIRECTED Graph") << std::endl;

    if (!load_original_graph(g, graph_path)) return -1;

    run_knn_experiment(g);
    return 0;
}