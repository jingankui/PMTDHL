#define NOMINMAX
#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <chrono>
#include <random>
#include <string>
#include <sstream>
#include <cstdint>
#include <windows.h>
#include <limits>
#include <omp.h>
#include <mutex>
#include <stdexcept>
#include <iomanip>
#include <atomic>  // 新增：线程安全原子计数

using NodeId = uint32_t;
using Distance = uint64_t;
using Index = size_t;
constexpr size_t QUERY_COUNT = 500;
// 🔥 修改1：时间间隔改为秒级 10/20/30/40/50/60秒
const std::vector<size_t> TIME_INTERVALS = { 10, 20, 30, 40, 50, 60, 70, 80};

enum class GraphType : uint8_t {
    DIRECTED,
    UNDIRECTED
};

// ===================== 新索引核心数据结构 =====================
struct ARData_Directed {
    std::vector<NodeId> A;
    std::vector<Distance> DOUT;
    std::vector<Distance> DIN;
    std::vector<NodeId> Acce;
};

struct ARData_Undirected {
    std::vector<NodeId> A;
    std::vector<Distance> D;
    std::vector<NodeId> Acce;
};

struct NodeIndex {
    Index ar_idx;
    std::vector<Index> P;
};

// ===================== 实验新增：原始图高效存储结构 =====================
struct OriginalGraph {
    std::unordered_map<NodeId, std::unordered_map<NodeId, Distance>> adj;
    uint32_t node_count = 0;
    uint32_t edge_count = 0;

    bool is_original_edge(NodeId a, NodeId b) const {
        auto it = adj.find(a);
        if (it == adj.end()) return false;
        return it->second.count(b) > 0;
    }
};

// ===================== 实验新增：分区邻接矩阵/表 =====================
struct PartitionAdjMatrix {
    std::string part_name;
    std::vector<NodeId> nodes;
    std::unordered_map<NodeId, Index> node2idx;
    std::vector<std::vector<int>> adj_mat;
    std::vector<std::vector<int>> lower_mat;
    std::unordered_map<NodeId, std::unordered_set<NodeId>> adj_list;
    size_t size;
};

// ===================== 图结构 =====================
struct Graph {
    GraphType type;
    uint32_t vertex_count = 0;
    uint32_t edge_count = 0;
    uint32_t tree_width = 0;
    uint32_t ar_count = 0;

    std::unordered_map<std::string, std::vector<NodeId>> partitions;
    std::unordered_map<NodeId, std::string> node_to_partition;
    std::unordered_set<NodeId> cover_graph_nodes;

    std::unordered_map<std::string, std::unordered_map<NodeId, NodeIndex>> part_dir_index;
    std::unordered_map<std::string, std::vector<ARData_Directed>> part_dir_ar;
    std::unordered_map<std::string, std::unordered_map<NodeId, NodeIndex>> part_undir_index;
    std::unordered_map<std::string, std::vector<ARData_Undirected>> part_undir_ar;

    std::unordered_map<NodeId, NodeIndex> cover_dir_index;
    std::vector<ARData_Directed> cover_dir_ar;
    std::unordered_map<NodeId, NodeIndex> cover_undir_index;
    std::vector<ARData_Undirected> cover_undir_ar;

    std::unordered_map<std::string, std::vector<NodeId>> partition_cover_intersection;
    OriginalGraph original_graph;
};

// ===================== 工具函数 =====================
static inline std::vector<std::string> split(const std::string& s, char delimiter) {
    std::vector<std::string> tokens;
    tokens.reserve(32);
    std::string token;
    std::istringstream tokenStream(s);
    while (std::getline(tokenStream, token, delimiter)) {
        if (!token.empty()) tokens.push_back(token);
    }
    return tokens;
}

static inline NodeId find_rightmost_lca(const std::vector<NodeId>& a, const std::vector<NodeId>& b) {
    const std::vector<NodeId>* longer = &a;
    const std::vector<NodeId>* shorter = &b;

    if (a.size() < b.size()) {
        longer = &b;
        shorter = &a;
    }

    for (int i = (int)longer->size() - 1; i >= 0; --i) {
        NodeId current = (*longer)[i];
        for (int j = (int)shorter->size() - 1; j >= 0; --j) {
            if (current == (*shorter)[j]) {
                return current;
            }
        }
    }
    return 0;
}

using TimePoint = std::chrono::high_resolution_clock::time_point;
static inline TimePoint now() { return std::chrono::high_resolution_clock::now(); }
static inline double elapsed_ms(TimePoint start, TimePoint end) {
    return std::chrono::duration<double, std::milli>(end - start).count();
}
static inline double elapsed_sec(TimePoint start, TimePoint end) {
    return std::chrono::duration<double>(end - start).count();
}

// ===================== 索引解析器 =====================
bool parse_index_file(const std::string& file_path, Graph& g) {
    std::ifstream file(file_path);
    if (!file.is_open()) {
        std::cerr << "Error: 打开索引文件失败 " << file_path << std::endl;
        return false;
    }

    std::string line;
    std::string current_part;
    bool in_overlay = false;
    bool in_index_map = false;
    bool in_data_array = false;
    Index current_ar = 0;

    while (std::getline(file, line)) {
        if (line.empty()) continue;

        if (line.size() >= 3 && line.substr(0, 3) == "===") {
            in_overlay = (line.find("Overlay") != std::string::npos);
            current_part.clear();

            if (!in_overlay) {
                auto parts = split(line, ' ');
                if (parts.size() >= 2) {
                    current_part = parts[1];
                    g.partitions[current_part];
                    g.part_undir_index[current_part];
                    g.part_undir_ar[current_part];
                    g.part_dir_index[current_part];
                    g.part_dir_ar[current_part];
                }
            }

            in_index_map = false;
            in_data_array = false;
            current_ar = 0;
            continue;
        }

        if (line.find("VertexCount:") != std::string::npos)
            g.vertex_count = std::stoul(split(line, ':')[1]);
        else if (line.find("EdgeCount:") != std::string::npos)
            g.edge_count = std::stoul(split(line, ':')[1]);
        else if (line.find("TreeWidth:") != std::string::npos)
            g.tree_width = std::stoul(split(line, ':')[1]);
        else if (line.find("NodeCount(AR):") != std::string::npos)
            g.ar_count = std::stoul(split(line, ':')[1]);
        else if (line == "GraphType: DIRECTED")
            g.type = GraphType::DIRECTED;
        else if (line == "GraphType: UNDIRECTED")
            g.type = GraphType::UNDIRECTED;

        if (line == "[INDEX_MAP]") {
            in_index_map = true;
            in_data_array = false;
            continue;
        }
        if (line == "[DATA_ARRAY]") {
            in_data_array = true;
            in_index_map = false;
            current_ar = 0;
            continue;
        }

        if (in_index_map) {
            size_t colon = line.find(':');
            if (colon == std::string::npos) continue;

            NodeId node_id = stoul(line.substr(0, colon));
            std::string content = line.substr(colon + 1);

            std::vector<int> nums;
            std::string num_str;
            for (char c : content) {
                if (isdigit(c)) {
                    num_str += c;
                }
                else {
                    if (!num_str.empty()) {
                        nums.push_back(stoi(num_str));
                        num_str.clear();
                    }
                }
            }
            if (!num_str.empty()) nums.push_back(stoi(num_str));
            if (nums.size() < 1) continue;

            Index ar_idx = nums[0];
            std::vector<Index> P(nums.begin() + 1, nums.end());

            if (in_overlay) {
                g.cover_graph_nodes.insert(node_id);
                if (g.type == GraphType::DIRECTED)
                    g.cover_dir_index[node_id] = { ar_idx, P };
                else
                    g.cover_undir_index[node_id] = { ar_idx, P };
            }
            else {
                if (current_part.empty()) continue;
                g.node_to_partition[node_id] = current_part;
                g.partitions[current_part].push_back(node_id);

                if (g.type == GraphType::DIRECTED)
                    g.part_dir_index[current_part][node_id] = { ar_idx, P };
                else
                    g.part_undir_index[current_part][node_id] = { ar_idx, P };
            }
            continue;
        }

        if (in_data_array) {
            if (line.substr(0, 3) == "Ar[") {
                current_ar = std::stoul(split(split(line, '[')[1], ']')[0]);

                if (g.type == GraphType::DIRECTED) {
                    if (in_overlay) {
                        if (current_ar >= g.cover_dir_ar.size())
                            g.cover_dir_ar.resize(current_ar + 1);
                    }
                    else {
                        if (!current_part.empty() && current_ar >= g.part_dir_ar[current_part].size())
                            g.part_dir_ar[current_part].resize(current_ar + 1);
                    }
                }
                else {
                    if (in_overlay) {
                        if (current_ar >= g.cover_undir_ar.size())
                            g.cover_undir_ar.resize(current_ar + 1);
                    }
                    else {
                        if (!current_part.empty() && current_ar >= g.part_undir_ar[current_part].size())
                            g.part_undir_ar[current_part].resize(current_ar + 1);
                    }
                }
                continue;
            }

            size_t left = line.find('[');
            size_t right = line.find(']');
            if (left == std::string::npos || right == std::string::npos) continue;
            auto tokens = split(line.substr(left + 1, right - left - 1), ',');

            if (g.type == GraphType::DIRECTED) {
                if (in_overlay) {
                    if (current_ar >= g.cover_dir_ar.size()) continue;
                    auto& ar = g.cover_dir_ar[current_ar];
                    if (line.find("A:") != std::string::npos)
                        for (auto& s : tokens) ar.A.push_back(std::stoul(s));
                    else if (line.find("DOUT:") != std::string::npos)
                        for (auto& s : tokens) ar.DOUT.push_back(std::stoull(s));
                    else if (line.find("DIN:") != std::string::npos)
                        for (auto& s : tokens) ar.DIN.push_back(std::stoull(s));
                }
                else {
                    if (current_part.empty() || current_ar >= g.part_dir_ar[current_part].size()) continue;
                    auto& ar = g.part_dir_ar[current_part][current_ar];
                    if (line.find("A:") != std::string::npos)
                        for (auto& s : tokens) ar.A.push_back(std::stoul(s));
                    else if (line.find("DOUT:") != std::string::npos)
                        for (auto& s : tokens) ar.DOUT.push_back(std::stoull(s));
                    else if (line.find("DIN:") != std::string::npos)
                        for (auto& s : tokens) ar.DIN.push_back(std::stoull(s));
                }
            }
            else {
                if (in_overlay) {
                    if (current_ar >= g.cover_undir_ar.size()) continue;
                    auto& ar = g.cover_undir_ar[current_ar];
                    if (line.find("A:") != std::string::npos)
                        for (auto& s : tokens) ar.A.push_back(std::stoul(s));
                    else if (line.find("D:") != std::string::npos)
                        for (auto& s : tokens) ar.D.push_back(std::stoull(s));
                }
                else {
                    if (current_part.empty() || current_ar >= g.part_undir_ar[current_part].size()) continue;
                    auto& ar = g.part_undir_ar[current_part][current_ar];
                    if (line.find("A:") != std::string::npos)
                        for (auto& s : tokens) ar.A.push_back(std::stoul(s));
                    else if (line.find("D:") != std::string::npos)
                        for (auto& s : tokens) ar.D.push_back(std::stoull(s));
                }
            }
        }
    }

    if (g.type == GraphType::DIRECTED) {
        for (auto& entry : g.part_dir_index) {
            auto& part = entry.first;
            auto& index_map = entry.second;
            auto& ar_list = g.part_dir_ar[part];
            for (auto& [node, idx] : index_map) {
                if (idx.ar_idx >= ar_list.size()) continue;
                auto& ar = ar_list[idx.ar_idx];
                ar.Acce.clear();
                for (size_t i = 0; i < idx.P.size(); i++) {
                    size_t pos = idx.P[i];
                    if (pos < ar.A.size()) ar.Acce.push_back(ar.A[pos]);
                }
            }
        }
        for (auto& [node, idx] : g.cover_dir_index) {
            if (idx.ar_idx >= g.cover_dir_ar.size()) continue;
            auto& ar = g.cover_dir_ar[idx.ar_idx];
            ar.Acce.clear();
            for (size_t i = 0; i < idx.P.size(); i++) {
                size_t pos = idx.P[i];
                if (pos < ar.A.size()) ar.Acce.push_back(ar.A[pos]);
            }
        }
    }
    else {
        for (auto& entry : g.part_undir_index) {
            auto& part = entry.first;
            auto& index_map = entry.second;
            auto& ar_list = g.part_undir_ar[part];
            for (auto& [node, idx] : index_map) {
                if (idx.ar_idx >= ar_list.size()) continue;
                auto& ar = ar_list[idx.ar_idx];
                ar.Acce.clear();
                for (size_t i = 0; i < idx.P.size(); i++) {
                    size_t pos = idx.P[i];
                    if (pos < ar.A.size()) ar.Acce.push_back(ar.A[pos]);
                }
            }
        }
        for (auto& [node, idx] : g.cover_undir_index) {
            if (idx.ar_idx >= g.cover_undir_ar.size()) continue;
            auto& ar = g.cover_undir_ar[idx.ar_idx];
            ar.Acce.clear();
            for (size_t i = 0; i < idx.P.size(); i++) {
                size_t pos = idx.P[i];
                if (pos < ar.A.size()) ar.Acce.push_back(ar.A[pos]);
            }
        }
    }

    if (g.type == GraphType::UNDIRECTED)
    {
        g.partition_cover_intersection.clear();
        for (auto& [part, nodes] : g.partitions) {
            std::vector<NodeId> inter;
            for (NodeId n : nodes) {
                if (g.cover_graph_nodes.count(n)) inter.push_back(n);
            }
            g.partition_cover_intersection[part] = inter;
        }
    }

    file.close();
    std::cout << "解析完成，分区数: " << g.partitions.size()
        << " 覆盖节点: " << g.cover_graph_nodes.size()
        << " Directed and Undirected Acce has been generated" << std::endl;
    return true;
}

bool load_original_graph(const std::string& file_path, Graph& g) {
    std::ifstream file(file_path);
    if (!file.is_open()) {
        std::cerr << "Error: 打开原始图文件失败 " << file_path << std::endl;
        return false;
    }

    OriginalGraph& og = g.original_graph;
    std::string line;

    std::getline(file, line);
    auto first_line = split(line, ' ');
    og.node_count = std::stoul(first_line[0]);
    og.edge_count = std::stoul(first_line[1]);

    while (std::getline(file, line)) {
        if (line.empty()) continue;
        auto parts = split(line, ' ');
        NodeId u = std::stoul(parts[0]);
        NodeId v = std::stoul(parts[1]);
        Distance w = std::stoull(parts[2]);
        og.adj[u][v] = w;
    }

    file.close();
    std::cout << "原始图加载完成：节点=" << og.node_count << " 边=" << og.edge_count << std::endl;
    return true;
}

bool build_partition_adj_matrix(Graph& g, const std::string& part_name, PartitionAdjMatrix& out_mat) {
    if (!g.partitions.count(part_name)) {
        std::cerr << "分区不存在: " << part_name << std::endl;
        return false;
    }

    out_mat.part_name = part_name;
    out_mat.nodes = g.partitions.at(part_name);
    auto& cover_nodes = g.cover_graph_nodes;
    auto& og = g.original_graph;

    out_mat.size = out_mat.nodes.size();
    for (Index i = 0; i < out_mat.size; i++) {
        out_mat.node2idx[out_mat.nodes[i]] = i;
    }

    out_mat.adj_mat.assign(out_mat.size, std::vector<int>(out_mat.size, 0));
    out_mat.lower_mat.assign(out_mat.size, std::vector<int>(out_mat.size, 0));
    out_mat.adj_list.clear();

    for (NodeId u : out_mat.nodes) {
        std::unordered_set<NodeId> neighbors;

        for (NodeId v : out_mat.nodes) {
            if (u == v) continue;
            if (og.is_original_edge(u, v)) {
                Index i = out_mat.node2idx[u];
                Index j = out_mat.node2idx[v];
                out_mat.adj_mat[i][j] = 1;
                neighbors.insert(v);
            }
        }

        if (cover_nodes.count(u)) {
            for (NodeId v : cover_nodes) {
                if (!out_mat.node2idx.count(v)) continue;
                if (og.is_original_edge(u, v) && !neighbors.count(v)) {
                    Index i = out_mat.node2idx[u];
                    Index j = out_mat.node2idx[v];
                    out_mat.adj_mat[i][j] = 1;
                    neighbors.insert(v);
                }
            }
        }

        out_mat.adj_list[u] = neighbors;
    }

    for (Index i = 0; i < out_mat.size; i++) {
        for (Index j = 0; j < out_mat.size; j++) {
            if (i > j) {
                out_mat.lower_mat[i][j] = out_mat.adj_mat[i][j];
            }
            else {
                out_mat.lower_mat[i][j] = 0;
            }
        }
    }

    std::cout << "分区 " << part_name << " 邻接矩阵构建完成，节点数=" << out_mat.size << std::endl;
    return true;
}

uint64_t triangle_count_strategy1(const PartitionAdjMatrix& mat, NodeId vi) {
    if (!mat.node2idx.count(vi)) return 0;
    Index i = mat.node2idx.at(vi);
    const auto& A = mat.adj_mat;
    const auto& A_hat = mat.lower_mat;
    size_t n = mat.size;

    const std::vector<int>& row_vi = A[i];
    std::vector<std::vector<int>> neighbor_rows;
    for (Index j = 0; j < n; j++) {
        if (row_vi[j] == 1) {
            neighbor_rows.push_back(A_hat[j]);
        }
    }

    std::vector<int> sum_row(n, 0);
    for (const auto& row : neighbor_rows) {
        for (Index j = 0; j < n; j++) {
            sum_row[j] += row[j];
        }
    }

    std::vector<int> mul_row(n, 0);
    for (Index j = 0; j < n; j++) {
        mul_row[j] = row_vi[j] * sum_row[j];
    }

    uint64_t count = 0;
    for (int val : mul_row) count += val;
    return count;
}

uint64_t triangle_count_strategy2(const PartitionAdjMatrix& mat, NodeId vi) {
    if (!mat.adj_list.count(vi)) return 0;
    const auto& N_vi = mat.adj_list.at(vi);
    uint64_t total = 0;

    for (NodeId vj : N_vi) {
        if (!mat.adj_list.count(vj)) continue;
        const auto& N_vj = mat.adj_list.at(vj);

        size_t intersect = 0;
        for (NodeId x : N_vj) {
            if (N_vi.count(x)) intersect++;
        }
        total += intersect;
    }

    return total / 2;
}

// 🔥 修改2：收集所有有效分区（节点数>QUERY_COUNT）
std::vector<std::string> get_all_valid_partitions(const Graph& g) {
    std::vector<std::string> valid_parts;
    for (const auto& [part, nodes] : g.partitions) {
        if (nodes.size() > QUERY_COUNT) {
            valid_parts.push_back(part);
        }
    }
    if (valid_parts.empty()) {
        std::cerr << "未找到节点数>" << QUERY_COUNT << "的有效分区！" << std::endl;
    }
    return valid_parts;
}

// 🔥 修改3：重构LCC实验函数 → 并行执行+循环分区+秒级计时+【正确分时间点输出】
void run_lcc_experiment(Graph& g) {
    if (g.type != GraphType::UNDIRECTED) {
        std::cerr << "LCC实验仅支持无向图!" << std::endl;
        return;
    }

    // 1. 获取所有有效分区
    std::vector<std::string> valid_partitions = get_all_valid_partitions(g);
    if (valid_partitions.empty()) return;
    std::cout << "有效分区总数: " << valid_partitions.size() << std::endl;
    std::cout << "----------------------------------------" << std::endl;

    // 🔥 关键：为每个时间点保存结果（10/20/30/40/50秒）
    std::vector<size_t> results1(TIME_INTERVALS.size(), 0);
    std::vector<size_t> results2(TIME_INTERVALS.size(), 0);

    // 🔥 并行独立执行两种策略
#pragma omp parallel sections default(none) shared(g, valid_partitions, results1, results2, std::cout, TIME_INTERVALS)
    {
#pragma omp section
        {
            std::cout << "Thread " << omp_get_thread_num() << ": Starting Strategy 1 (Matrix Calculation)" << std::endl;
            auto start = now();
            size_t time_idx = 0;
            const size_t max_time = TIME_INTERVALS.back();
            size_t count = 0;

            while (time_idx < TIME_INTERVALS.size()) {
                double cur_sec = elapsed_sec(start, now());
                if (cur_sec > max_time) break;

                for (const auto& part : valid_partitions) {
                    PartitionAdjMatrix mat;
                    if (!build_partition_adj_matrix(g, part, mat)) continue;

                    for (NodeId node : mat.nodes) {
                        cur_sec = elapsed_sec(start, now());
                        if (cur_sec > max_time) goto END_STRATEGY1;

                        // 计数
                        triangle_count_strategy1(mat, node);
                        count++;

                        // 到达时间点 → 保存结果
                        while (time_idx < TIME_INTERVALS.size() && cur_sec >= TIME_INTERVALS[time_idx]) {
                            results1[time_idx] = count;
                            std::cout << "[Strategy 1] " << TIME_INTERVALS[time_idx] << "s -> " << count << " nodes" << std::endl;
                            time_idx++;
                        }
                    }
                }
            }
        END_STRATEGY1:
            // 把未填满的时间点全部补成最终值
            while (time_idx < TIME_INTERVALS.size()) {
                results1[time_idx] = count;
                time_idx++;
            }
            std::cout << "Thread " << omp_get_thread_num() << ": Strategy 1 finished" << std::endl;
        }

#pragma omp section
        {
            std::cout << "Thread " << omp_get_thread_num() << ": Starting Strategy 2 (Adjacency List Intersection)" << std::endl;
            auto start = now();
            size_t time_idx = 0;
            const size_t max_time = TIME_INTERVALS.back();
            size_t count = 0;

            while (time_idx < TIME_INTERVALS.size()) {
                double cur_sec = elapsed_sec(start, now());
                if (cur_sec > max_time) break;

                for (const auto& part : valid_partitions) {
                    PartitionAdjMatrix mat;
                    if (!build_partition_adj_matrix(g, part, mat)) continue;

                    for (NodeId node : mat.nodes) {
                        cur_sec = elapsed_sec(start, now());
                        if (cur_sec > max_time) goto END_STRATEGY2;

                        triangle_count_strategy2(mat, node);
                        count++;

                        while (time_idx < TIME_INTERVALS.size() && cur_sec >= TIME_INTERVALS[time_idx]) {
                            results2[time_idx] = count;
                            std::cout << "[Strategy 2] " << TIME_INTERVALS[time_idx] << "s -> " << count << " nodes" << std::endl;
                            time_idx++;
                        }
                    }
                }
            }
        END_STRATEGY2:
            while (time_idx < TIME_INTERVALS.size()) {
                results2[time_idx] = count;
                time_idx++;
            }
            std::cout << "Thread " << omp_get_thread_num() << ": Strategy 2 finished" << std::endl;
        }
    }

    // 🔥 最终输出：每个时间点对应当时的结果
    std::cout << "\n----------------------------------------" << std::endl;
    std::cout << "Final Experiment Results (Correct Time Points)" << std::endl;
    std::cout << std::left << std::setw(15) << "Time(s)"
        << std::setw(15) << "Strategy 1"
        << std::setw(15) << "Strategy 2" << std::endl;

    for (int i = 0; i < TIME_INTERVALS.size(); i++) {
        std::cout << std::left << std::setw(15) << TIME_INTERVALS[i]
            << std::setw(15) << results1[i]
            << std::setw(15) << results2[i] << std::endl;
    }
    std::cout << "----------------------------------------" << std::endl;
}

// ===================== 原有查询函数（无修改） =====================
Distance query_directed(const Graph& g, NodeId va, NodeId vb) {
    std::string part = g.node_to_partition.at(va);
    const auto& idx_map = g.part_dir_index.at(part);
    const auto& ar_data = g.part_dir_ar.at(part);

    const NodeIndex& idx_a = idx_map.at(va);
    const NodeIndex& idx_b = idx_map.at(vb);
    const ARData_Directed& ar_a = ar_data[idx_a.ar_idx];
    const ARData_Directed& ar_b = ar_data[idx_b.ar_idx];

    NodeId descendant, ancestor;
    const ARData_Directed* desc_ar;
    if (idx_a.ar_idx > idx_b.ar_idx) {
        descendant = va; ancestor = vb; desc_ar = &ar_a;
    }
    else {
        descendant = vb; ancestor = va; desc_ar = &ar_b;
    }

    auto it = std::find(desc_ar->A.begin(), desc_ar->A.end(), ancestor);
    if (it != desc_ar->A.end()) {
        Index pos = it - desc_ar->A.begin();
        if (va == descendant && vb == ancestor) {
            return (pos < desc_ar->DOUT.size()) ? desc_ar->DOUT[pos] : UINT64_MAX;
        }
        else {
            return (pos < desc_ar->DIN.size()) ? desc_ar->DIN[pos] : UINT64_MAX;
        }
    }

    NodeId lca = find_rightmost_lca(ar_a.A, ar_b.A);
    if (lca == 0) return UINT64_MAX;
    const NodeIndex& idx_lca = idx_map.at(lca);

    Distance min_dist = UINT64_MAX;
    for (Index p : idx_lca.P) {
        if (p >= ar_a.DOUT.size() || p >= ar_b.DIN.size()) continue;
        Distance sum = ar_a.DOUT[p] + ar_b.DIN[p];
        if (sum < min_dist) min_dist = sum;
    }
    return min_dist;
}

Distance query_undir_part(const Graph& g, const std::string& part, NodeId va, NodeId vb) {
    const auto& idx_map = g.part_undir_index.at(part);
    const auto& ar_data = g.part_undir_ar.at(part);
    const NodeIndex& idx_a = idx_map.at(va);
    const NodeIndex& idx_b = idx_map.at(vb);
    const ARData_Undirected& ar_a = ar_data[idx_a.ar_idx];
    const ARData_Undirected& ar_b = ar_data[idx_b.ar_idx];

    const ARData_Undirected* desc_ar = (idx_a.ar_idx > idx_b.ar_idx) ? &ar_a : &ar_b;
    NodeId target = (idx_a.ar_idx > idx_b.ar_idx) ? vb : va;

    auto it = std::find(desc_ar->A.begin(), desc_ar->A.end(), target);
    if (it != desc_ar->A.end()) {
        Index pos = it - desc_ar->A.begin();
        return (pos < desc_ar->D.size()) ? desc_ar->D[pos] : UINT64_MAX;
    }

    NodeId lca = find_rightmost_lca(ar_a.A, ar_b.A);
    if (lca == 0) return UINT64_MAX;
    const NodeIndex& idx_lca = idx_map.at(lca);

    Distance min_dist = UINT64_MAX;
    for (Index p : idx_lca.P) {
        if (p >= ar_a.D.size() || p >= ar_b.D.size()) continue;
        Distance sum = ar_a.D[p] + ar_b.D[p];
        if (sum < min_dist) min_dist = sum;
    }
    return min_dist;
}

Distance query_undir_cover(const Graph& g, NodeId va, NodeId vb) {
    const NodeIndex& idx_a = g.cover_undir_index.at(va);
    const NodeIndex& idx_b = g.cover_undir_index.at(vb);
    const ARData_Undirected& ar_a = g.cover_undir_ar[idx_a.ar_idx];
    const ARData_Undirected& ar_b = g.cover_undir_ar[idx_b.ar_idx];

    const ARData_Undirected* desc_ar = (idx_a.ar_idx > idx_b.ar_idx) ? &ar_a : &ar_b;
    NodeId target = (idx_a.ar_idx > idx_b.ar_idx) ? vb : va;

    auto it = std::find(desc_ar->A.begin(), desc_ar->A.end(), target);
    if (it != desc_ar->A.end()) {
        Index pos = it - desc_ar->A.begin();
        return (pos < desc_ar->D.size()) ? desc_ar->D[pos] : UINT64_MAX;
    }

    NodeId lca = find_rightmost_lca(ar_a.A, ar_b.A);
    if (lca == 0) return UINT64_MAX;
    const NodeIndex& idx_lca = g.cover_undir_index.at(lca);

    Distance min_dist = UINT64_MAX;
    for (Index p : idx_lca.P) {
        Distance sum = ar_a.D[p] + ar_b.D[p];
        if (sum < min_dist) min_dist = sum;
    }
    return min_dist;
}

Distance calculate_three_stage_min(const Graph& g, const std::string& p1, const std::string& p2,
    NodeId va, NodeId vb, const std::vector<NodeId>& C1, const std::vector<NodeId>& C2) {
    Distance min_total = UINT64_MAX;
    for (NodeId c1 : C1) {
        Distance d1 = query_undir_part(g, p1, va, c1);
        if (d1 == UINT64_MAX) continue;
        for (NodeId c2 : C2) {
            Distance d2 = query_undir_cover(g, c1, c2);
            if (d2 == UINT64_MAX) continue;
            for (NodeId c3 : C2) {
                Distance d3 = query_undir_part(g, p2, c3, vb);
                if (d3 == UINT64_MAX) continue;
                Distance total = d1 + d2 + d3;
                if (total < min_total) min_total = total;
            }
        }
    }
    return min_total;
}

Distance query_same_part_cross_best(const Graph& g, NodeId c1, NodeId c2) {
    std::string part = g.node_to_partition.at(c1);
    Distance d_part = query_undir_part(g, part, c1, c2);
    Distance d_cover = query_undir_cover(g, c1, c2);
    Distance res = UINT64_MAX;
    if (d_part != UINT64_MAX) res = d_part;
    if (d_cover != UINT64_MAX && d_cover < res) res = d_cover;
    return res;
}

Distance query_cross_part_via_cover(const Graph& g, NodeId c1, NodeId c2) {
    return query_undir_cover(g, c1, c2);
}

Distance calculate_three_stage_same_part(const Graph& g, const std::string& part,
    NodeId va, NodeId vb, const std::vector<NodeId>& C) {
    Distance min_total = UINT64_MAX;
    for (NodeId c1 : C) {
        Distance d1 = query_undir_part(g, part, va, c1);
        if (d1 == UINT64_MAX) continue;
        for (NodeId c2 : C) {
            Distance d2 = query_same_part_cross_best(g, c1, c2);
            if (d2 == UINT64_MAX) continue;
            for (NodeId c3 : C) {
                Distance d3 = query_undir_part(g, part, c3, vb);
                if (d3 == UINT64_MAX) continue;
                Distance total = d1 + d2 + d3;
                if (total < min_total) min_total = total;
            }
        }
    }
    return min_total;
}

Distance calculate_three_stage_cross_part(const Graph& g, const std::string& p1, const std::string& p2,
    NodeId va, NodeId vb, const std::vector<NodeId>& C1, const std::vector<NodeId>& C2) {
    Distance min_total = UINT64_MAX;
    for (NodeId c1 : C1) {
        Distance d1 = query_undir_part(g, p1, va, c1);
        if (d1 == UINT64_MAX) continue;
        for (NodeId c2 : C2) {
            Distance d2 = query_cross_part_via_cover(g, c1, c2);
            if (d2 == UINT64_MAX) continue;
            for (NodeId c3 : C2) {
                Distance d3 = query_undir_part(g, p2, c3, vb);
                if (d3 == UINT64_MAX) continue;
                Distance total = d1 + d2 + d3;
                if (total < min_total) min_total = total;
            }
        }
    }
    return min_total;
}

Distance query_undirected_local(const Graph& g, NodeId va, NodeId vb) {
    std::string part = g.node_to_partition.at(va);
    Distance mind1 = query_undir_part(g, part, va, vb);
    if (g.cover_graph_nodes.empty()) return mind1;
    const auto& C = g.partition_cover_intersection.at(part);
    if (C.empty()) return mind1;
    Distance mind2 = calculate_three_stage_same_part(g, part, va, vb, C);
    Distance res = mind1;
    if (mind2 != UINT64_MAX && mind2 < res) res = mind2;
    return res;
}

Distance query_undirected_cross(const Graph& g, NodeId va, NodeId vb) {
    if (g.cover_graph_nodes.empty()) {
        std::cout << "===== 覆盖图为空 =====" << std::endl;
        return query_undirected_local(g, va, vb);
    }
    std::string p1 = g.node_to_partition.at(va);
    std::string p2 = g.node_to_partition.at(vb);
    const auto& C1 = g.partition_cover_intersection.at(p1);
    const auto& C2 = g.partition_cover_intersection.at(p2);
    if (C1.empty() || C2.empty()) {
        return query_undirected_local(g, va, vb);
    }
    return calculate_three_stage_cross_part(g, p1, p2, va, vb, C1, C2);
}

void save_pairs_to_file(const std::vector<std::pair<NodeId, NodeId>>& pairs, const std::string& filename) {
    std::ofstream f(filename);
    for (auto& p : pairs) f << p.first << " " << p.second << "\n";
}

std::vector<std::pair<NodeId, NodeId>> load_pairs_from_file(const std::string& filename) {
    std::vector<std::pair<NodeId, NodeId>> pairs;
    std::ifstream f(filename);
    NodeId u, v;
    while (f >> u >> v) pairs.emplace_back(u, v);
    return pairs;
}

static std::mutex rng_mtx;
static std::mt19937 rng(std::random_device{}());

std::vector<std::pair<NodeId, NodeId>> generate_local_pairs(Graph& g) {
    return load_pairs_from_file("local_pairs.txt");
}

std::vector<std::pair<NodeId, NodeId>> generate_cross_pairs(Graph& g) {
    return load_pairs_from_file("cross_pairs.txt");
}

void run_parallel_queries(Graph& g, size_t threads) {
    omp_set_num_threads((int)threads);

    if (g.type == GraphType::DIRECTED) {
        std::vector<NodeId> all_nodes;
        for (auto& kv : g.partitions) for (NodeId n : kv.second) all_nodes.push_back(n);
        std::vector<std::pair<NodeId, NodeId>> pairs;
        {
            std::lock_guard<std::mutex> l(rng_mtx);
            std::uniform_int_distribution<> d(0, all_nodes.size() - 1);
            for (size_t i = 0; i < QUERY_COUNT; i++) pairs.emplace_back(all_nodes[d(rng)], all_nodes[d(rng)]);
        }

        auto st = now();
        std::vector<Distance> res(QUERY_COUNT);
#pragma omp parallel for
        for (int i = 0; i < (int)QUERY_COUNT; i++) {
            res[i] = query_directed(g, pairs[i].first, pairs[i].second);
        }
        auto ed = now();

        std::cout << "===== 有向图分区内查询结果 =====" << std::endl;
        std::cout << "总耗时: " << elapsed_ms(st, ed) << "ms | 平均: " << elapsed_ms(st, ed) / QUERY_COUNT << "ms" << std::endl;
    }
    else {
        auto local_p = generate_local_pairs(g);
        std::cout << "Random node generation within the partition is complete" << std::endl;
        auto st1 = now();
        std::vector<Distance> rl(QUERY_COUNT);
#pragma omp parallel for
        for (int i = 0; i < (int)QUERY_COUNT; i++) {
            rl[i] = query_undirected_local(g, local_p[i].first, local_p[i].second);
        }
        auto ed1 = now();
        std::cout << "===== 无向图分区内查询 =====" << std::endl;
        std::cout << "总耗时: " << elapsed_ms(st1, ed1) << "ms | 平均: " << elapsed_ms(st1, ed1) / QUERY_COUNT << "ms" << std::endl;

        auto cross_p = generate_cross_pairs(g);
        std::cout << "Cross-partition random node generation complete" << std::endl;
        auto st2 = now();
        std::vector<Distance> rc(QUERY_COUNT);
#pragma omp parallel for
        for (int i = 0; i < (int)QUERY_COUNT; i++) {
            rc[i] = query_undirected_cross(g, cross_p[i].first, cross_p[i].second);
        }
        auto ed2 = now();
        std::cout << "===== 无向图跨分区查询 =====" << std::endl;
        std::cout << "总耗时: " << elapsed_ms(st2, ed2) << "ms | 平均: " << elapsed_ms(st2, ed2) / QUERY_COUNT << "ms" << std::endl;
    }
}

// ===================== 主函数 =====================
/*int main() {
    SetConsoleOutputCP(CP_UTF8);
    Graph g;

    auto st1 = now();
    std::cout << "开始解析索引文件..." << std::endl;
    std::string index_path = "./PMTDHL/FLA/tdhl_index.txt";
    if (!parse_index_file(index_path, g)) {
        return -1;
    }
    auto ed1 = now();
    std::cout << "索引解析总耗时: " << elapsed_ms(st1, ed1) << "ms " << std::endl;
    std::cout << "图类型: " << (g.type == GraphType::DIRECTED ? "DIRECTED Graph" : "UnDIRECTED Graph") << std::endl;

    std::string original_graph_path = "FLA.txt";
    if (!load_original_graph(original_graph_path, g)) {
        return -1;
    }

    // 执行重构后的LCC实验
    run_lcc_experiment(g);

    // run_parallel_queries(g, 4);

    return 0;
}*/

#include <queue>
#include <algorithm>
#include <iomanip>
#include <fstream>
#include <thread>
#include <vector>
#include <mutex>

using ResultHeap = std::priority_queue<std::pair<Distance, NodeId>>;
using SearchQueue = std::priority_queue<std::pair<Distance, NodeId>,
    std::vector<std::pair<Distance, NodeId>>, std::greater<>>;

const int THREAD_COUNT = 8;

bool knn_query(
    Graph& g,
    const PartitionAdjMatrix& mat,
    NodeId vs, int k,
    std::vector<std::pair<NodeId, Distance>>& knn_result)
{
    knn_result.clear();
    if (k <= 0 || !mat.adj_list.count(vs)) return false;
    const auto& adj = mat.adj_list;

    ResultHeap result_heap;
    std::unordered_set<NodeId> visited;
    SearchQueue pq;
    pq.emplace(0, vs);

    while (!pq.empty()) {
        auto [current_dist, u] = pq.top();
        pq.pop();

        if (result_heap.size() == k && current_dist > result_heap.top().first)
            break;

        if (visited.count(u)) continue;
        visited.insert(u);

        if (u != vs) {
            if (result_heap.size() < k)
                result_heap.emplace(current_dist, u);
            else if (current_dist < result_heap.top().first) {
                result_heap.pop();
                result_heap.emplace(current_dist, u);
            }
        }

        if (!adj.count(u)) continue;
        for (NodeId v : adj.at(u)) {
            if (visited.count(v)) continue;
            Distance d = query_undirected_local(g, vs, v);
            if (d == UINT64_MAX) continue;
            pq.emplace(d, v);
        }
    }

    while (!result_heap.empty()) {
        auto [d, v] = result_heap.top();
        result_heap.pop();
        knn_result.emplace_back(v, d);
    }
    std::reverse(knn_result.begin(), knn_result.end());
    return true;
}

std::vector<std::pair<std::string, NodeId>> load_query_nodes(const std::string& filename) {
    std::vector<std::pair<std::string, NodeId>> res;
    std::ifstream f(filename);
    std::string part;
    NodeId q;
    while (f >> part >> q) res.emplace_back(part, q);
    return res;
}

void run_knn_experiment(Graph& g) {
    std::vector<int> COUNTS = { 50,60,70,80,90 };
    std::vector<int> Ks = { 3,5 };

    auto parts = get_all_valid_partitions(g);
    if (parts.empty()) return;

    std::cout << "提前构建分区邻接矩阵...\n";
    std::unordered_map<std::string, PartitionAdjMatrix> mats;
    for (auto& p : parts)
        build_partition_adj_matrix(g, p, mats[p]);

    std::cout << "\n======== 新索引 8线程并行 KNN ========\n";
    for (int cnt : COUNTS) {
        auto nodes = load_query_nodes("query_nodes_" + std::to_string(cnt) + ".txt");
        std::cout << "\n>>> " << cnt << " 个节点（8线程）\n";

        for (int k : Ks) {
            auto st = now();
            int total_ok = 0;
            std::mutex mtx;

            auto worker = [&](int start, int end) {
                int local_ok = 0;
                for (int i = start; i < end; ++i) {
                    auto& [part, q] = nodes[i];
                    std::vector<std::pair<NodeId, Distance>> tmp;
                    if (knn_query(g, mats[part], q, k, tmp))
                    {
                        local_ok++;
                        std::lock_guard<std::mutex> lock(mtx);
                        std::cout << "已经完成 " << q << " 的 " << k << "NN 计算\n";
                    }
                }
                std::lock_guard<std::mutex> lock(mtx);
                total_ok += local_ok;
                };

            int total = nodes.size();
            int per = total / THREAD_COUNT;
            std::vector<std::thread> threads;
            for (int t = 0; t < THREAD_COUNT; ++t) {
                int s = t * per;
                int e = (t == THREAD_COUNT - 1) ? total : (t + 1) * per;
                threads.emplace_back(worker, s, e);
            }
            for (auto& th : threads) th.join();

            double cost = elapsed_sec(st, now());
            std::cout << k << "NN: " << cost << " s\n";
        }
    }
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    Graph g;
    auto st1 = now();
    std::cout << "开始解析索引文件..." << std::endl;
    std::string index_path = "./PMTDHL/COL/tdhl_index.txt";
    if (!parse_index_file(index_path, g)) return -1;
    auto ed1 = now();
    std::cout << "索引解析总耗时: " << elapsed_ms(st1, ed1) << "ms " << std::endl;
    std::cout << "图类型: " << (g.type == GraphType::DIRECTED ? "DIRECTED Graph" : "UnDIRECTED Graph") << std::endl;
    std::string original_graph_path = "./COL.txt";
    if (!load_original_graph(original_graph_path, g)) return -1;

    run_knn_experiment(g);
    return 0;
}